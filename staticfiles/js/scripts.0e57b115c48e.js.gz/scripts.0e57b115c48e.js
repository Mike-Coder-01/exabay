const translations = {
  en: {
    navLabel: "Primary navigation",
    searchProducts: "Search Exxabay products",
    navSearchPlaceholder: "Search trusted products, brands, sellers",
    heroSearchPlaceholder: "What are you looking for today?",
    search: "Search",
    viewCart: "View cart",
    openProfile: "Open profile",
    switchLanguage: "Switch language to Swahili",
    heroEyebrow: "Trust-first marketplace",
    heroTitle: "Buy from verified sellers with confidence",
    heroCopy: "Discover everyday essentials, electronics, fashion, and home goods with visible seller verification on every listing.",
    popularCategories: "Popular categories",
    catElectronics: "Electronics",
    catHome: "Home",
    catFashion: "Fashion",
    catBeauty: "Beauty",
    trustSummary: "Marketplace trust summary",
    trustSignalTitle: "Verified seller signals",
    trustSignalCopy: "Business checks, document status, and order metrics shown before you buy.",
    averageRating: "Average seller rating",
    completedTrustedOrders: "Completed trusted orders",
    featuredMarketplace: "Featured marketplace",
    productsTitle: "Products from credible sellers",
    filterSellers: "Filter sellers",
    seller: "Seller",
    viewSellerTrust: "View Seller Trust",
    addToCart: "Add to Cart",
    viewDetails: "View Details",
    inStock: "In Stock",
    lowStock: "Low Stock",
    verified: "Verified",
    pending: "Pending",
    unverified: "Unverified",
    sellerTrustProfile: "Seller trust profile",
    verificationStatus: "Verification Status",
    documents: "Documents",
    sensitivePreviewsHidden: "Sensitive previews hidden",
    sellerMetrics: "Seller Metrics",
    totalProducts: "Total products",
    completedOrders: "Completed orders",
    rating: "Rating",
    closeTrustDetails: "Close seller trust details",
    viewDocument: "Available on request",
    stars: "stars",
    businessLicense: "Business License",
    idVerification: "ID Verification",
    storeRegistration: "Store Registration",
    taxClearance: "Tax Clearance Document",
    noProductsTitle: "No products available",
    noProductsCopy: "Please check back soon for trusted marketplace listings.",
    submitted: "Submitted",
    missing: "Missing",
    unavailable: "Unavailable",
    trustCopyVerified: "This seller has been verified by Exxabay and meets our trust standards.",
    trustCopyPending: "This seller has submitted the required trust profile information and is waiting for Exxabay review.",
    trustCopyUnverified: "This seller has not completed Exxabay's verification checks yet.",

    // REFUND POLICY

    refundPolicyTitle: "Refund & Return Policy",
    refundPolicyEyebrow: "Shop with confidence",
    refundPolicySummary: "Exxabay protects buyers by keeping the payment process secure and providing a clear process for reporting problems, returning eligible products, and requesting refunds.",
    refundPolicyBadge: "Buyer protection",

    refundPolicyPaymentProtectionTitle: "Payment protection",
    refundPolicyPaymentProtectionBody: "When you place an order through Exxabay, your payment is held through our secure payment and escrow process while the order is being fulfilled. Seller payout is processed according to the order and confirmation process.",

    refundPolicyCheckOrderTitle: "Check your order",
    refundPolicyCheckOrderBody: "After receiving your order, carefully check that the product is the correct item, matches the listing, and is not damaged or missing important accessories. If there is a problem, report it through Exxabay before confirming your order.",

    refundPolicyRequestRefundTitle: "When can I request a refund?",
    refundPolicyRequestRefundBody: "You may be eligible for a refund or other remedy if you receive the wrong product, a product that is materially different from the listing, a damaged or defective product, an incomplete order, or if the seller fails to fulfil your order. Refunds are also subject to any rights provided by applicable Tanzanian law.",

    refundPolicyReportProblemTitle: "Report a problem",
    refundPolicyReportProblemBody: "If there is a problem with your order, open the relevant order in your Exxabay account and select the option to report a problem. You may be asked to provide photos, videos, delivery information, or other evidence to help us review the case.",

    refundPolicyDisputeReviewTitle: "Dispute review",
    refundPolicyDisputeReviewBody: "When a buyer reports a problem, Exxabay may temporarily hold the transaction while the issue is reviewed. We may contact the buyer and seller and review the product listing, order information, delivery details, and evidence provided by both parties before determining the appropriate resolution.",

    refundPolicyPossibleResolutionsTitle: "Possible resolutions",
    refundPolicyPossibleResolutionsBody: "Depending on the circumstances, Exxabay may determine that the appropriate resolution is a replacement, repair, partial refund, full refund, return of the product, or release of the payment to the seller.",

    refundPolicyProductReturnsTitle: "Product returns",
    refundPolicyProductReturnsBody: "If a return is approved, buyers must follow Exxabay's return instructions. Products should generally be returned in substantially the same condition in which they were received, together with the supplied accessories and packaging where reasonably available.",

    refundPolicyReturnCostsTitle: "Return delivery costs",
    refundPolicyReturnCostsBody: "Where the seller sent the wrong product, materially misrepresented the product, or the product is defective or damaged due to circumstances attributable to the seller, the seller may be responsible for applicable return costs. Where a return is made because of a buyer's change of mind, the buyer may be responsible for return costs where permitted by applicable law.",

    refundPolicyChangeMindTitle: "Change of mind",
    refundPolicyChangeMindBody: "Changing your mind does not automatically guarantee a refund or free return. Any cancellation or return rights will be handled according to applicable Tanzanian law, the product category, and the applicable seller return terms.",

    refundPolicyProcessingTitle: "Refund processing",
    refundPolicyProcessingBody: "Once a refund is approved, Exxabay will initiate the refund through the applicable payment channel. The refund may be full or partial depending on the outcome of the case. The time required for the refunded amount to reach the buyer may depend on the payment provider or financial institution.",

    refundPolicyAfterConfirmationTitle: "After confirming your order",
    refundPolicyAfterConfirmationBody: "Once you confirm that your order has been received satisfactorily, the normal order dispute process may no longer apply to ordinary delivery-related complaints. However, genuine defects or other issues may still be handled under an applicable warranty, seller return policy, consumer protection right, or other applicable remedy.",

    refundPolicyFraudulentClaimsTitle: "Fraudulent or abusive claims",
    refundPolicyFraudulentClaimsBody: "Exxabay may investigate and take appropriate action where there is reasonable evidence of fraudulent or abusive refund activity, including false non-delivery claims, returning a different product, deliberately damaging a product, or submitting misleading evidence.",

    refundPolicySellerResponsibilityTitle: "Seller responsibility",
    refundPolicySellerResponsibilityBody: "Sellers are responsible for ensuring that their product descriptions, images, specifications, prices, and availability are accurate and that products supplied to buyers match their listings. Sellers must also comply with applicable return, warranty, and consumer protection requirements.",

    refundPolicyExxabayRoleTitle: "Exxabay's role",
    refundPolicyExxabayRoleBody: "Exxabay operates the marketplace and provides the systems used to facilitate transactions between buyers and verified sellers. When a dispute occurs, Exxabay may review the available information and administer the applicable buyer-protection and escrow process.",

    refundPolicyApplicableLawTitle: "Applicable law",
    refundPolicyApplicableLawBody: "This policy is subject to applicable laws and regulations of Tanzania. Nothing in this policy is intended to remove or limit a consumer right or remedy that cannot legally be excluded.",

    refundPolicyViewOrders: "View my orders",
    refundPolicyContactSupport: "Contact support",
    refundPolicyViewProducts: "View products",

    // FOOTER
    footerAboutExxabay: "Buy from verified sellers with confidence. Exxabay helps shoppers discover products while keeping seller credibility visible.",
    footerOkVerified: "OK Verified sellers",
    secureCheckout: "Secure Checkout",
    buyerProtection: "Buyer Protection",
    marketplaceUpdates: "Marketplace updates",
    getTrustedDealsAndSellersUpdates: "Get trusted deals and seller updates",
    receiveProductDrops: "Receive product drops, buyer protection updates, and seller verification news.",
    emailAdress: "Email address",
    enterYourEmail: "Enter your email",
    subscribe: "Subscribe",
    shop: "Shop",
    allProducts: "All Products",
    categories: "Categories",
    newArrivals: "New Arrivals",
    sellOnExxabay: "Sell on Exxabay",
    becomeASeller: "Become a Seller",
    sellerVerification: "Seller Verification",
    completeSellerProfile: "Complete Seller Profile",
    sellerGuidelines: "Seller Guidelines",
    customerSupport: "Customer Support",
    helpCenter: "Help Centre",
    trackOrder: "Track Order",
    returnsAndRefunds: "Returns and Refunds",
    contactSupport: "Contact Support",
    trustAndLegal: "Trust and Legal",
    buyerProtection: "Buyer Protection",
    sellerVerificationPolicy: "Seller Verification Policy",
    privacyPolicy: "Privacy Policy",
    termsOfServices: "Terms of Services",
    reportsASeller: "Report a Seller",
    allRightReserved: "2026 Exxabay. All rights reserved.",
    callNow: "Call now",

    // PRODUCT DETAILS PAGE
    backToMarketplace: "Back to marketplace",
    productInformation: "Product information",
    description: "Description",
    sellerCredibility: "Seller credibility",
    verificationDocuments: "Verification documents",
    sellerDocuments: "Seller documents",
    specifications: "Specifications",
    productDetails: "Product details",
    noSpecifications: "No extra specifications have been added for this product yet.",
    stock: "Stock",
    availability: "Availability",
    listed: "Listed",
    available: "Available",
    unavailable: "Unavailable",
    addToCart: "Add to Cart",
    continueShopping: "Continue Shopping",
    lowStock: "Low Stock",
    inStock: "In Stock",
    featured: "Featured",
    okVerified: "OK Verified",
    pendingStatus: "! Pending",
    unverifiedStatus: "X Unverified",
    verifiedSellerCopy: "This seller has been verified by Exxabay and meets our trust standards.",
    pendingSellerCopy: "This seller has submitted required trust information and is waiting for Exxabay review.",
    unverifiedSellerCopy: "This seller has not completed Exxabay's verification checks yet.",
    totalProducts: "Total products",
    completedOrders: "Completed orders",
    rating: "Rating",
    businessLicenseDoc: "Business License",
    taxClearanceDoc: "Tax Clearance Document",
    idTinVerification: "ID / TIN Verification",
    storeRegistration: "Store Registration",
    onFileSubmitted: "On file - Submitted",
    notSubmittedMissing: "Not submitted - Missing",
    tinOnFile: "TIN on file - Submitted",
    businessProfileOnFile: "Business profile on file - Submitted",
    viewDocument: "Available on request",
    uncategorized: "Uncategorized",

    // CART
    secureMarketplaceCart: "Secure marketplace cart",
    yourShoppingCart: "Your shopping cart",
    cartHeroCopy: "Review seller details, quantities, and totals before moving to mobile money checkout.",
    trustProtectedCheckout: "Trust-protected checkout",
    trustProtectedCheckoutCopy: "Seller verification remains visible throughout your order journey.",
    marketplaceOrder: "Marketplace order",
    itemsInYourCart: "Items in your cart",
    cartProductsBySellers: "Cart products by marketplace sellers",
    sellerLabel: "Seller:",
    price: "Price",
    quantity: "Quantity",
    subtotal: "Subtotal",
    remove: "Remove",
    orderSummary: "Order summary",
    cartTotal: "Cart total",
    itemsSubtotal: "Items subtotal",
    delivery: "Delivery",
    calculatedAtCheckout: "Calculated at checkout",
    trustProtection: "Trust protection",
    included: "Included",
    total: "Total",
    proceedToCheckout: "Proceed to Checkout",
    mobileMoneySupported: "Mobile money supported",
    mobileMoneyNote: "Pay securely with M-Pesa, Tigo Pesa, Airtel Money, during checkout.",
    cartEmpty: "Your cart is empty",
    cartEmptyCopy: "Start exploring trusted products from verified sellers across Exxabay.",
    decreaseQuantity: "Decrease quantity",
    increaseQuantity: "Increase quantity",
    Charges: "Charges",
    AmountPayable: "Amount payable",
    PaymentPhoneNumber: "Payment phone number",

    // ORDER DETAILS
    awaitingPayment: "Awaiting payment",
    paymentConfirmed: "Payment confirmed",
    paymentFailed: "Payment failed",
    orderTitle: "Order #",
    awaitingPaymentCopy: "A payment prompt has been sent to your phone. Please authorise it to complete your order.",
    paymentConfirmedCopy: "Your mobile money payment was successful. Below is your trusted marketplace order summary.",
    paymentFailedCopy: "Your payment was not completed. Your cart has not been affected, you can try again below.",
    waitingForConfirmation: "Waiting for confirmation",
    checkYourPhone: "Check your phone for the USSD prompt and enter your PIN.",
    checkoutCompleted: "Checkout completed",
    checkoutCompletedCopy: "Seller trust and payment records are attached to this order.",
    paymentUnsuccessful: "Payment unsuccessful",
    paymentUnsuccessfulCopy: "No money was charged. Please try again or use a different number.",
    tryAgain: "Try Again",
    orderItems: "Order items",
    purchasedProducts: "Purchased products",
    unitPrice: "Unit price",
    noOrderItems: "No order items found",
    noOrderItemsCopy: "This order does not have any products attached.",
    receipt: "Receipt",
    orderSummaryTitle: "Order summary",
    statusLabel: "Status",
    paymentMethod: "Payment method",
    paymentStatus: "Payment status",
    transactionId: "Transaction ID",
    totalPaid: "Total paid",
    mobileMoneyThankYou: "Simplified payment process with your mobile phone.",
    mobileMoney: "Mobile money",


    // SELLER ANALYTICS
    sellerAnalytics: "Seller analytics",
    businessPerformanceCenter: "Business performance center",
    businessPerformanceCopy: "Understand revenue, order health, buyer behavior, inventory risk, and top-performing products from one seller workspace.",
    verifiedSellerAnalytics: "Verified seller analytics",
    analyticsVisiblePending: "Analytics visible while verification is in progress",
    performanceOverview: "Performance overview",
    businessAnalysis: "Business analysis",
    analyticsDateFilter: "Analytics date filter",
    fromDate: "From date",
    toDate: "To date",
    applyFilter: "Apply filter",
    clearFilter: "Clear",
    keyBusinessMetrics: "Key business metrics",
    keyBusinessMetricsCopy: "Revenue and order health for the selected period.",
    revenueLabel: "Revenue",
    ordersLabel: "Orders",
    aovLabel: "AOV",
    riskLabel: "Risk",
    grossRevenue: "Gross Revenue",
    paidActiveOrders: "Paid / Active Orders",
    averageOrderValue: "Average Order Value",
    cancellationRate: "Cancellation Rate",
    orderHealth: "Order health",
    orderHealthCopy: "Track paid orders, fulfillment progress, and completion performance.",
    pendingOrders: "Pending",
    paidOrders: "Paid",
    processingOrders: "Processing",
    completedOrders: "Completed",
    completedRate: "Completed rate",
    unitsSold: "Units sold",
    recentSalesTrend: "Recent sales trend",
    recentSalesTrendCopy: "Last available sales days in the selected period.",
    noSalesTrend: "No sales trend yet",
    noSalesTrendCopy: "Paid, processing, and completed sales will appear here.",
    topProducts: "Top products",
    topProductsCopy: "Best-performing products by revenue.",
    productCol: "Product",
    categoryCol: "Category",
    ordersCol: "Orders",
    unitsCol: "Units",
    revenueCol: "Revenue",
    stockCol: "Stock",
    outOfStock: "Out of stock",
    noProductData: "No paid product performance data yet.",
    actionQueue: "Action queue",
    actionQueueCopy: "Orders that need seller attention first.",
    callBuyer: "Call buyer",
    noUrgentOrders: "No urgent orders",
    noUrgentOrdersCopy: "Pending, paid, and processing orders will appear here.",
    businessSnapshot: "Business snapshot",
    sellerHealth: "Seller health",
    productsLabel: "Products",
    activeProducts: "Active products",
    lowStockLabel: "Low stock",
    outOfStockLabel: "Out of stock",
    featuredLabel: "Featured",
    inventoryValue: "Inventory value",
    uniqueBuyers: "Unique buyers",
    repeatBuyers: "Repeat buyers",
    sellerStatusLabel: "Seller status",
    completionRateLabel: "Completion rate",
    cancelledOrders: "Cancelled orders",
    verifiedStatus: "Verified",
    pendingReview: "Pending review",
    reviewPaidOrders: "Review paid orders",
    openOrders: "Open orders",
    analysisNote: "Analysis note",
    analysisNoteCopy: "Revenue uses paid, processing, and completed seller order lines. Pending and cancelled orders are shown for operational awareness.",
    noCategoryData: "No category data yet",
    noCategoryDataCopy: "Category performance appears after paid sales.",
    noStatusData: "No status data",
    noStatusDataCopy: "Order status breakdown will appear here.",

    // SELLER ORDER
    sellerOrderCenter: "Seller order center",
    ordersSoldOnExxabay: "Orders sold on Exxabay",
    sellerOrderCenterCopy: "Track paid orders, pending fulfillment, buyer details, product history, and seller revenue from one trust-focused workspace.",
    verifiedSellerProfile: "Verified seller profile",
    sellerVerificationInProgress: "Seller verification in progress",
    orderHistory: "Order history",
    soldProducts: "Sold products",
    sellerOrderItems: "Seller order items",
    buyerLabel: "Buyer:",
    emailBuyer: "Email buyer",
    noPhoneNumber: "No phone number",
    sellerSubtotal: "Seller subtotal",
    noSellerOrders: "No seller orders yet",
    noSellerOrdersCopy: "Orders for your products will appear here after buyers complete checkout.",
    okCompleted: "OK Completed",
    sellerSummary: "Seller summary",
    orderPerformance: "Order performance",
    totalRevenue: "Total revenue",
    uniqueOrders: "Unique orders",
    pendingActive: "Pending / active",
    fulfillmentFocus: "Fulfillment focus",
    fulfillmentFocusCopy: "Paid and pending orders",
    paymentMode: "Payment mode",
    paymentModeCopy: "Mobile money",
    viewPaidOrders: "View paid orders",
    viewAllHistory: "View all history",

    // BUYER DASHBOARD
    buyerAccount: "Buyer account",
    accountWelcome: "Welcome,",
    accountHeroCopy: "Manage your orders, update your details, and track your trusted marketplace activity.",
    trustProtectedAccount: "Trust-protected account",
    trustProtectedAccountCopy: "Your purchases are secured by Exxabay's seller verification system.",
    totalOrders: "Total orders",
    completedOrders: "Completed",
    pendingPayment: "Pending payment",
    actionRequired: "Action required",
    pendingPayments: "Pending payments",
    pendingCount: "pending",
    orderHistoryEyebrow: "Order history",
    allOrders: "All orders",
    totalCount: "total",
    payNow: "Pay now →",
    viewOrder: "View",
    totalLabel: "Total",
    okPaid: "OK Paid",
    okDelivered: "OK Delivered",
    shippedStatus: "⟶ Shipped",
    cancelledStatus: "X Cancelled",
    noOrdersYet: "No orders yet",
    noOrdersCopy: "You haven't placed any orders. Explore trusted sellers and start shopping.",
    browseProducts: "Browse products",
    personalDetails: "Personal details",
    editAccount: "Edit account",
    firstName: "First name",
    lastName: "Last name",
    emailAddress: "Email address",
    phoneNumber: "Phone number",
    usernameLabel: "Username",
    changePassword: "Change password",
    newPassword: "New password",
    confirmPassword: "Confirm password",
    leaveBlankPassword: "Leave blank to keep your current password.",
    saveChanges: "Save changes",
    cancelButton: "Cancel",
    growWithExxabay: "Grow with Exxabay",
    startSelling: "Start selling on Exxabay",
    startSellingCopy: "Join thousands of verified sellers. List your products, reach trusted buyers, and grow your business on Tanzania's trust-first marketplace.",
    verifiedListings: "✓ Verified listings",
    mobileMoneyPayouts: "✓ Mobile money payouts",
    sellerDashboardPill: "✓ Seller dashboard",
    freeToRegister: "✓ Free to register",
    becomeSellerCta: "Become a seller →",
    memberSince: "Member since",
    phoneLabel: "Phone",
    usernameField: "Username",
    ordersField: "Orders",
    signOut: "Sign out",
    hereForYou: "We are here for you",
    talkToExxabay: "Talk to Exxabay",
    callUsDirectly: "Call us directly",
    callHours: "Mon–Sat, 8am–6pm EAT",
    whatsappSupport: "WhatsApp support",
    whatsappCopy: "Faster responses for order issues.",
    openWhatsapp: "Open WhatsApp",
    emailSupport: "Email support",
    sendEmail: "Send email",


    // FOOTER PAGES POLICY, TERMS OF SERVICES

    navLabel: "Primary navigation",
    searchProducts: "Search Exxabay products",
    navSearchPlaceholder: "Search trusted products, brands, sellers",
    heroSearchPlaceholder: "What are you looking for today?",
    search: "Search",
    viewCart: "View cart",
    openProfile: "Open profile",
    switchLanguage: "Switch language to Swahili",
    heroEyebrow: "Trust-first marketplace",
    heroTitle: "Buy from verified sellers with confidence",
    heroCopy: "Discover everyday essentials, electronics, fashion, and home goods with visible seller verification on every listing.",
    popularCategories: "Popular categories",
    catElectronics: "Electronics",
    catHome: "Home",
    catFashion: "Fashion",
    catBeauty: "Beauty",
    trustSummary: "Marketplace trust summary",
    trustSignalTitle: "Verified seller signals",
    trustSignalCopy: "Business checks, document status, and order metrics shown before you buy.",
    averageRating: "Average seller rating",
    completedTrustedOrders: "Completed trusted orders",
    featuredMarketplace: "Featured marketplace",
    productsTitle: "Products from credible sellers",
    filterSellers: "Filter sellers",
    seller: "Seller",
    viewSellerTrust: "View Seller Trust",
    addToCart: "Add to Cart",
    viewDetails: "View Details",
    inStock: "In Stock",
    lowStock: "Low Stock",
    verified: "Verified",
    pending: "Pending",
    unverified: "Unverified",
    sellerTrustProfile: "Seller trust profile",
    verificationStatus: "Verification Status",
    documents: "Documents",
    sensitivePreviewsHidden: "Sensitive previews hidden",
    sellerMetrics: "Seller Metrics",
    totalProducts: "Total products",
    completedOrders: "Completed orders",
    rating: "Rating",
    closeTrustDetails: "Close seller trust details",
    viewDocument: "Available on request",
    stars: "stars",
    businessLicense: "Business License",
    idVerification: "ID Verification",
    storeRegistration: "Store Registration",
    taxClearance: "Tax Clearance Document",
    noProductsTitle: "No products available",
    noProductsCopy: "Please check back soon for trusted marketplace listings.",
    submitted: "Submitted",
    missing: "Missing",
    unavailable: "Unavailable",
    trustCopyVerified: "This seller has been verified by Exxabay and meets our trust standards.",
    trustCopyPending: "This seller has submitted the required trust profile information and is waiting for Exxabay review.",
    trustCopyUnverified: "This seller has not completed Exxabay's verification checks yet.",
    policyHeroTrustCopy: "Exxabay policies are built around safer buyer and seller relationships.",
    exabayPolicy: "Exxabay policy",
    sectionsLabel: "sections",
    trustCenter: "Trust center",
    relatedActions: "Related actions",
    policyLabel: "Policy",
    focusLabel: "Focus",
    marketplaceLabel: "Marketplace",
    importantNote: "Important note",
    policyImportantNoteCopy: "This page gives marketplace guidance. Exxabay may update policies as products, payments, and seller requirements evolve.",
    buyerProtectionEyebrow: "Shop with confidence",
    buyerProtectionTitle: "Buyer Protection",
    buyerProtectionSummary: "Exxabay helps buyers shop safely by combining verified seller signals, secure payment flow, and clear order follow-up.",
    buyerProtectionBadge: "Buyer safety",
    buyerProtectionSection1Title: "Verified seller visibility",
    buyerProtectionSection1Body: "Product pages and seller cards show verification status so buyers can quickly understand whether a seller has completed Exxabay trust checks.",
    buyerProtectionSection2Title: "Secure payment flow",
    buyerProtectionSection2Body: "Buyers should complete payment only through Exxabay-supported checkout channels. Sellers must not request private PINs, passwords, or off-platform payment confirmation.",
    buyerProtectionSection3Title: "Order follow-up",
    buyerProtectionSection3Body: "Paid orders can be monitored by Exxabay admins to help sellers and buyers coordinate fulfillment and delivery confirmation.",
    buyerProtectionSection4Title: "Report and review process",
    buyerProtectionSection4Body: "If a product is misleading, not delivered, or connected to suspicious seller behavior, buyers can submit a seller report for review.",
    buyerProtectionAction1: "Report a seller",
    buyerProtectionAction2: "View products",
    sellerVerificationPolicyEyebrow: "Marketplace trust",
    sellerVerificationPolicyTitle: "Seller Verification Policy",
    sellerVerificationPolicySummary: "Exxabay verifies seller identity and business information before giving sellers full trusted marketplace access.",
    sellerVerificationPolicyBadge: "Verification",
    sellerVerificationPolicySection1Title: "Required business information",
    sellerVerificationPolicySection1Body: "Sellers may be asked to provide a business name, TIN number, business license document, license expiry date, and other supporting tax or registration details.",
    sellerVerificationPolicySection2Title: "Admin review",
    sellerVerificationPolicySection2Body: "Exxabay admins review submitted seller information and may verify, reject, or request corrections before trust status is shown to buyers.",
    sellerVerificationPolicySection3Title: "Document privacy",
    sellerVerificationPolicySection3Body: "Verification documents are used for marketplace trust review and are not displayed as sensitive previews on public product pages.",
    sellerVerificationPolicySection4Title: "Ongoing trust checks",
    sellerVerificationPolicySection4Body: "Verified status can be removed if a seller provides false information, violates marketplace rules, or fails to maintain valid verification records.",
    sellerVerificationPolicyAction1: "Complete seller profile",
    sellerVerificationPolicyAction2: "Seller guidelines",
    privacyPolicyEyebrow: "Data and trust",
    privacyPolicyTitle: "Privacy Policy",
    privacyPolicySummary: "Exxabay collects only the information needed to operate accounts, orders, seller verification, payments, payouts, and marketplace support.",
    privacyPolicyBadge: "Privacy",
    privacyPolicySection1Title: "Information we collect",
    privacyPolicySection1Body: "We may collect account details, contact information, order records, payment references, seller business documents, and support messages.",
    privacyPolicySection2Title: "How information is used",
    privacyPolicySection2Body: "Information is used to manage accounts, process orders, verify sellers, support payments and payouts, prevent fraud, and communicate marketplace updates.",
    privacyPolicySection3Title: "Sharing and security",
    privacyPolicySection3Body: "Exxabay may share required transaction details with payment providers and operational partners. Sensitive seller documents should be protected and accessed only by authorized review users.",
    privacyPolicySection4Title: "Your choices",
    privacyPolicySection4Body: "Users can update account details, notification preferences, and seller settings from their account pages where available.",
    privacyPolicyAction1: "Account settings",
    privacyPolicyAction2: "Contact support",
    termsOfServiceEyebrow: "Marketplace rules",
    termsOfServiceTitle: "Terms of Service",
    termsOfServiceSummary: "These terms explain the responsibilities of buyers, sellers, and Exxabay when using the marketplace.",
    termsOfServiceBadge: "Terms",
    termsOfServiceSection1Title: "Account responsibility",
    termsOfServiceSection1Body: "Users are responsible for keeping account credentials secure and providing accurate registration, contact, and seller information.",
    termsOfServiceSection2Title: "Marketplace role",
    termsOfServiceSection2Body: "Exxabay provides a marketplace platform for product discovery, checkout, seller verification, order follow-up, and payout support.",
    termsOfServiceSection3Title: "Seller obligations",
    termsOfServiceSection3Body: "Sellers must list accurate products, maintain stock information, fulfill paid orders, communicate professionally, and comply with verification requirements.",
    termsOfServiceSection4Title: "Buyer obligations",
    termsOfServiceSection4Body: "Buyers must provide accurate order and contact information, complete payments through supported channels, and avoid abusive or fraudulent activity.",
    termsOfServiceSection5Title: "Policy enforcement",
    termsOfServiceSection5Body: "Exxabay may restrict accounts, remove listings, reject verification, pause payouts, or cancel orders when marketplace safety requires action.",
    termsOfServiceAction1: "Buyer protection",
    termsOfServiceAction2: "Seller guidelines",
    sellerGuidelinesEyebrow: "Sell responsibly",
    sellerGuidelinesTitle: "Seller Guidelines",
    sellerGuidelinesSummary: "These guidelines help sellers build buyer trust, reduce disputes, and maintain healthy marketplace performance.",
    sellerGuidelinesBadge: "Seller standards",
    sellerGuidelinesSection1Title: "Accurate listings",
    sellerGuidelinesSection1Body: "Product names, images, descriptions, specifications, prices, and stock counts should be truthful and kept up to date.",
    sellerGuidelinesSection2Title: "Reliable fulfillment",
    sellerGuidelinesSection2Body: "Sellers should prepare paid orders promptly, communicate clearly with buyers, and update order handling when fulfillment changes.",
    sellerGuidelinesSection3Title: "Professional communication",
    sellerGuidelinesSection3Body: "Sellers must communicate respectfully and should not request sensitive payment credentials or push buyers outside protected checkout channels.",
    sellerGuidelinesSection4Title: "Trust and verification",
    sellerGuidelinesSection4Body: "Business documents and payout details should remain accurate. Expired or incorrect records may delay verification or payouts.",
    sellerGuidelinesSection5Title: "Payout readiness",
    sellerGuidelinesSection5Body: "Payouts are based on eligible seller earnings after marketplace commission and depend on valid payout details and completed fulfillment.",
    sellerGuidelinesAction1: "Seller settings",
    sellerGuidelinesAction2: "Verification policy",
    reportSellerEyebrow: "Marketplace safety",
    reportSellerTitle: "Report a seller",
    reportSellerSummary: "Tell Exxabay about suspicious seller behavior, misleading products, delivery issues, or trust concerns.",
    reportSellerTrustCopy: "Reports help Exxabay review sellers and keep marketplace trust signals meaningful.",
    safetyReport: "Safety report",
    sellerReportDetails: "Seller report details",
    supportReview: "Support review",
    reportStatus: "Report status",
    reportSellerNameLabel: "Seller or store name",
    reportOrderIdLabel: "Order ID",
    optionalLabel: "Optional",
    reportEmailLabel: "Your email",
    reportReasonLabel: "Reason",
    reportDetailsLabel: "What happened?",
    reportEvidenceLabel: "Evidence link",
    submitReport: "Submit report",
    beforeSubmitting: "Before submitting",
    helpfulDetails: "Helpful details",
    includeLabel: "Include",
    includeReportDetails: "Seller name, order ID, product, and timeline",
    avoidLabel: "Avoid",
    avoidReportDetails: "Passwords, PINs, and sensitive payment credentials",
    reviewLabel: "Review",
    reviewReportDetails: "Exxabay support checks reports for marketplace risk",
    urgentSafetyIssue: "Urgent safety issue?",
    urgentSafetyIssueCopy: "If money or account access is at immediate risk, contact Exxabay support directly in addition to submitting this report.",
    reportSellerNamePlaceholder: "Seller or store name",
    reportOrderIdPlaceholder: "Order ID, if available",
    reportEmailPlaceholder: "Your email address",
    reportDetailsPlaceholder: "Describe what happened. Do not include passwords, PINs, or sensitive payment credentials.",
    reportEvidencePlaceholder: "Optional evidence link",
    reportReason_fake_product: "Fake or misleading product",
    reportReason_fraud: "Fraud or suspicious payment request",
    reportReason_non_delivery: "Product not delivered",
    reportReason_poor_communication: "Poor or unsafe communication",
    reportReason_document_trust: "Seller trust concern",
    reportReason_other: "Other",


    // EXXABAY GO
    howItWorksEyebrow: "How it works",
    howItWorksTitle: "Simple. Secure. Instant.",

    howStep1Title: "Apply and get verified",
    howStep1Desc: "Submit your TIN, business license, national ID, and shop photos. Approved within 48 hours.",

    howStep2Title: "List products or use Exxabay Go",
    howStep2Desc: "Add products to the marketplace, or generate secure payment links for your WhatsApp and Instagram customers.",

    howStep3Title: "Customer pays securely",
    howStep3Desc: "Buyers pay via M-Pesa, Airtel Money, Halopesa, or Mixx by Yas.",

    howStep4Title: "Receive funds instantly",
    howStep4Desc: "Marketplace: Get paid instantly. Exxabay Go: customer pays the small fee, you receive 100% of your agreed amount.",

    whyExxabayEyebrow: "Why Exxabay",
    whyExxabayTitle: "Trust built into every transaction",

    whyCard1Title: "Every seller verified",
    whyCard1Desc: "TIN, business license, national ID, and shop address confirmed before any seller goes live.",

    whyCard2Title: "Exxabay Go",
    whyCard2Desc: "Accept payments from WhatsApp and Instagram customers through a verified, secure link.",

    whyCard3Title: "Legal accountability",
    whyCard3Desc: "If a seller defrauds you, we release their full legal details for police action. No one can hide.",

    whyCard4Title: "No upfront costs",
    whyCard4Desc: "No listing fees. No monthly fees.",

    "exxabayGo.hero.badge": "EXXABAY GO",
  "exxabayGo.hero.new": "NEW",
  "exxabayGo.hero.title": "Sell anywhere. Get paid securely.",
  "exxabayGo.hero.description":
    "Already selling on WhatsApp, Instagram, or Facebook? Exxabay Go lets verified sellers send a secure payment link to any customer no marketplace listing needed. Only Tsh 1,500 + 1% per transaction.",

  "exxabayGo.hero.platform.whatsapp": "WhatsApp",
  "exxabayGo.hero.platform.instagram": "Instagram",
  "exxabayGo.hero.platform.facebook": "Facebook",
  "exxabayGo.hero.platform.sms": "SMS",

  "exxabayGo.hero.cta": "Learn more about Exxabay Go",
  "exxabayGo.hero.note": "Available to Exxabay verified sellers only",

  "exxabayGo.hero.step1": "Seller enters customer number + amount",
  "exxabayGo.hero.step2": "Exxabay generates a secure verified payment link",
  "exxabayGo.hero.step3": "Customer pays via M-Pesa, Airtel, Halopesa, or Mixx",
  "exxabayGo.hero.step4": "Seller receives 100% of agreed amount instantly",


  // EXXABAY GO LANDING PAGE
  "hero.eyebrow": "Exxabay Go",
    "hero.title_line1": "Sell anywhere.",
    "hero.title_line2": "Get paid securely.",
    "hero.subtitle": "A portable payment tool for verified Exxabay sellers. Send a secure, branded payment link to any customer on WhatsApp, Instagram, or SMS no marketplace listing required.",
    "hero.note": "Available to Exxabay verified sellers only",
    "common.dashboard_cta": "Go to seller dashboard",
    "stats.fee_label": "Base fee per link",
    "stats.percent_label": "Of transaction amount",
    "stats.instant": "Instant",
    "stats.payout_label": "Seller payout",
    "how.eyebrow": "How it works",
    "how.title": "Three steps to a secure payment",
    "how.step1_title": "Enter customer's WhatsApp number and amount",
    "how.step1_desc": "Open Exxabay Go from your seller dashboard. Two fields only phone number and amount. The fee is calculated and locked the moment you generate the link.",
    "how.step2_title": "Send the payment link",
    "how.step2_desc": "Click \"Send via WhatsApp\" the link goes directly to your customer with a pre-written Swahili message. Or send via SMS. The link shows your verified business name and the exact amount the customer needs to pay.",
    "how.step3_title": "Customer pays, you receive funds instantly",
    "how.step3_desc": "Your customer pays from any mobile money number they choose M-Pesa, Airtel Money, Halopesa, or Mixx by Yas. You receive 100% of the agreed amount. The small Exxabay Go fee is paid by the customer on top.",
    "fee.eyebrow": "Fee structure",
    "fee.title": "Simple and transparent",
    "fee.formula": "Tsh 1,500 + 1% of transaction amount",
    "fee.row_seller_enters": "Seller enters amount",
    "fee.row_fee": "Exxabay Go fee (paid by customer)",
    "fee.row_total": "Customer pays total",
    "fee.row_receives": "Seller receives",
    "fee.note": "The fee is paid by the customer, not the seller. It is locked permanently at link generation. The seller always receives exactly the agreed amount regardless of transaction size.",
    "who.eyebrow": "Who can use Exxabay Go",
    "who.title": "Built for verified sellers",
    "who.card1_title": "Verified marketplace sellers only",
    "who.card1_desc": "You must have completed full Exxabay verification TIN, business license, national ID, and shop photos before accessing Exxabay Go. No exceptions.",
    "who.card2_title": "Sellers with WhatsApp and social media customers",
    "who.card2_desc": "Keep selling exactly where you are on WhatsApp, Instagram, or Facebook with a secure, verified payment layer your customers can trust.",
    "who.card3_title": "Sellers growing beyond the marketplace",
    "who.card3_desc": "Accept payments from any customer you find anywhere, while keeping your Exxabay verification and trust profile working for you.",
    "protect.eyebrow": "Buyer protection",
    "protect.title": "Every payment is protected",
    "protect.subtitle": "When a buyer pays through your Exxabay Go link, they see your verified name and a clear accountability guarantee before paying.",
    "protect.item1": "Buyer sees your verified business name and Exxabay Verified status before paying",
    "protect.item2": "Payment link shows the exact amount no hidden charges, full transparency",
    "protect.item3": "If a seller fails to deliver, Exxabay releases their full legal name, national ID, and shop address for police action",
    "protect.item4": "Buyer is invited to create an Exxabay account after payment only never forced before",
    "faq.eyebrow": "Common questions",
    "faq.title": "Frequently asked",
    "faq.q1": "Do I need to list a product to use Exxabay Go?",
    "faq.a1": "No. Exxabay Go requires only a customer phone number and an amount. No product listing, no photos, no category selection. It is designed entirely for off-platform and social media sales.",
    "faq.q2": "Can my customer pay from a different mobile number?",
    "faq.a2": "Yes. You enter your customer's WhatsApp number to send the link. But when the customer opens the link they can pay from any mobile money number they choose. They are not locked to the number you entered.",
    "faq.q3": "Who pays the Exxabay Go fee?",
    "faq.a3": "The customer pays the fee on top of the agreed amount. You always receive exactly the amount you entered when generating the link. The fee is shown transparently to the customer before they confirm payment.",
    "faq.q4": "Can the fee change after I generate a link?",
    "faq.a4": "No. The fee is permanently locked the moment you click generate. Even if Exxabay updates its fee structure in the future, that specific link will always show the fee that was calculated at the moment of generation.",
    "faq.q5": "How do I get access to Exxabay Go?",
    "faq.a5": "Exxabay Go is available inside your seller dashboard once your Exxabay verification is complete. If you have not yet been verified, apply as a seller on Exxabay first. The verification process takes up to 48 hours.",
    "faq.q6": "What is the difference between Exxabay Go and the marketplace?",
    "faq.a6": "The Exxabay Marketplace is where buyers discover your products through search and browse. Exxabay Go is for customers you find yourself on WhatsApp, Instagram, or anywhere you sell. On the marketplace, sellers pay a 10% commission. On Exxabay Go, customers pay Tsh 1,500 + 1% and sellers receive 100% of the agreed amount.",
    "bottom.title": "Ready to use Exxabay Go?",
    "bottom.subtitle": "Access Exxabay Go from your seller dashboard. Generate your first secure payment link in under a minute.",
    "bottom.apply_cta": "Not verified yet? apply as a seller",

  },


  sw: {
    navLabel: "Urambazaji mkuu",
    searchProducts: "Tafuta bidhaa za Exxabay",
    navSearchPlaceholder: "Tafuta bidhaa, chapa, na wauzaji wa kuaminika",
    heroSearchPlaceholder: "Unatafuta nini leo?",
    search: "Tafuta",
    viewCart: "Tazama kikapu",
    openProfile: "Fungua wasifu",
    switchLanguage: "Badilisha lugha kwenda Kiingereza",
    heroEyebrow: "Soko linalotanguliza uaminifu",
    heroTitle: "Nunua kutoka kwa wauzaji waliothibitishwa kwa kujiamini",
    heroCopy: "Gundua mahitaji ya kila siku, elektroniki, mitindo, na bidhaa za nyumbani zikiwa na uthibitisho wa muuzaji kwenye kila tangazo.",
    popularCategories: "Makundi maarufu",
    catElectronics: "Elektroniki",
    catHome: "Nyumbani",
    catFashion: "Mitindo",
    catBeauty: "Urembo",
    trustSummary: "Muhtasari wa uaminifu wa soko",
    trustSignalTitle: "Ishara za muuzaji aliyethibitishwa",
    trustSignalCopy: "Ukaguzi wa biashara, hali ya nyaraka, na takwimu za oda huonekana kabla ya kununua.",
    averageRating: "Wastani wa alama za wauzaji",
    completedTrustedOrders: "Oda salama zilizokamilika",
    featuredMarketplace: "Soko lililoangaziwa",
    productsTitle: "Bidhaa kutoka kwa wauzaji wa kuaminika",
    filterSellers: "Chuja wauzaji",
    seller: "Muuzaji",
    viewSellerTrust: "Tazama Uaminifu wa Muuzaji",
    addToCart: "Ongeza Kikapuni",
    viewDetails: "Tazama Maelezo",
    inStock: "Ipo dukani",
    lowStock: "Inakaribia kuisha",
    verified: "Imethibitishwa",
    pending: "Inasubiri",
    unverified: "Haijathibitishwa",
    sellerTrustProfile: "Wasifu wa uaminifu wa muuzaji",
    verificationStatus: "Hali ya Uthibitisho",
    documents: "Nyaraka",
    sensitivePreviewsHidden: "Muonekano wa taarifa nyeti umefichwa",
    sellerMetrics: "Takwimu za Muuzaji",
    totalProducts: "Jumla ya bidhaa",
    completedOrders: "Oda zilizokamilika",
    rating: "Alama",
    closeTrustDetails: "Funga maelezo ya uaminifu wa muuzaji",
    viewDocument: "Inapatikana unapohitaji",
    stars: "nyota",
    businessLicense: "Leseni ya Biashara",
    idVerification: "Uthibitisho wa Kitambulisho",
    storeRegistration: "Usajili wa Duka",
    taxClearance: "Nyaraka ya Ulipaji Kodi",
    noProductsTitle: "Hakuna bidhaa zilizopo",
    noProductsCopy: "Tafadhali rudi tena hivi karibuni kwa matangazo ya soko la kuaminika.",
    submitted: "Imewasilishwa",
    missing: "Haipo",
    unavailable: "Haipatikani",
    trustCopyVerified: "Muuzaji huyu amethibitishwa na Exxabay na anakidhi viwango vyetu vya uaminifu.",
    trustCopyPending: "Muuzaji huyu amewasilisha taarifa muhimu za wasifu wa uaminifu na anasubiri ukaguzi wa Exxabay.",
    trustCopyUnverified: "Muuzaji huyu bado hajakamilisha ukaguzi wa uthibitisho wa Exxabay.",

    // REFUND POLICY
    refundPolicyTitle: "Sera ya Marejesho na Kurudisha Bidhaa",
    refundPolicyEyebrow: "Nunua kwa kujiamini",
    refundPolicySummary: "Exxabay inalinda wanunuzi kwa kuweka mchakato wa malipo katika mfumo salama na kutoa utaratibu wazi wa kuripoti matatizo, kurudisha bidhaa zinazostahili, na kuomba marejesho ya fedha.",
    refundPolicyBadge: "Ulinzi wa mnunuzi",

    refundPolicyPaymentProtectionTitle: "Ulinzi wa malipo",
    refundPolicyPaymentProtectionBody: "Unapoweka oda kupitia Exxabay, malipo yako yanahifadhiwa kupitia mfumo wetu salama wa malipo na escrow wakati oda yako inatekelezwa. Malipo kwa muuzaji hufanyika kulingana na mchakato wa oda na uthibitisho wa kupokea bidhaa.",

    refundPolicyCheckOrderTitle: "Kagua oda yako",
    refundPolicyCheckOrderBody: "Baada ya kupokea oda yako, kagua kwa makini ili kuhakikisha kuwa umepewa bidhaa sahihi, inalingana na maelezo ya tangazo, na haijaharibika au kukosa vifaa muhimu. Ikiwa kuna tatizo, liripoti kupitia Exxabay kabla ya kuthibitisha oda yako.",

    refundPolicyRequestRefundTitle: "Ni wakati gani ninaweza kuomba marejesho ya fedha?",
    refundPolicyRequestRefundBody: "Unaweza kustahili kurejeshewa fedha au kupata suluhisho jingine ikiwa umepokea bidhaa isiyo sahihi, bidhaa ambayo inatofautiana kwa kiasi kikubwa na maelezo ya tangazo, bidhaa iliyoharibika au yenye hitilafu, oda isiyokamilika, au ikiwa muuzaji ameshindwa kutekeleza oda yako. Marejesho ya fedha pia yanategemea haki zinazotolewa chini ya sheria zinazotumika nchini Tanzania.",

    refundPolicyReportProblemTitle: "Ripoti tatizo",
    refundPolicyReportProblemBody: "Ikiwa kuna tatizo na oda yako, fungua oda husika kwenye akaunti yako ya Exxabay na uchague chaguo la kuripoti tatizo. Unaweza kuombwa kutoa picha, video, taarifa za uwasilishaji, au ushahidi mwingine utakaotusaidia kupitia suala hilo.",

    refundPolicyDisputeReviewTitle: "Mapitio ya mgogoro",
    refundPolicyDisputeReviewBody: "Mnunuzi anaporipoti tatizo, Exxabay inaweza kusimamisha kwa muda mchakato wa malipo wakati suala hilo linapitiwa. Tunaweza kuwasiliana na mnunuzi na muuzaji na kupitia maelezo ya bidhaa, taarifa za oda, taarifa za uwasilishaji, pamoja na ushahidi uliowasilishwa na pande zote kabla ya kuamua suluhisho linalofaa.",

    refundPolicyPossibleResolutionsTitle: "Suluhisho zinazowezekana",
    refundPolicyPossibleResolutionsBody: "Kulingana na mazingira ya suala, Exxabay inaweza kuamua kuwa suluhisho linalofaa ni kubadilisha bidhaa, kutengeneza bidhaa, kurejesha sehemu ya fedha, kurejesha fedha zote, kurudisha bidhaa, au kuendelea na malipo kwa muuzaji.",

    refundPolicyProductReturnsTitle: "Kurudisha bidhaa",
    refundPolicyProductReturnsBody: "Ikiwa ombi la kurudisha bidhaa limekubaliwa, mnunuzi lazima afuate maelekezo ya Exxabay kuhusu namna ya kurudisha bidhaa. Kwa kawaida, bidhaa inapaswa kurudishwa katika hali inayokaribiana na ile ilivyokuwa ilipopokelewa, pamoja na vifaa vilivyotolewa na kifungashio pale inapowezekana.",

    refundPolicyReturnCostsTitle: "Gharama za kurudisha bidhaa",
    refundPolicyReturnCostsBody: "Ikiwa muuzaji ametuma bidhaa isiyo sahihi, ametoa maelezo yanayopotosha kuhusu bidhaa, au bidhaa ina hitilafu au imeharibika kutokana na mazingira yanayohusishwa na muuzaji, muuzaji anaweza kuwajibika kwa gharama husika za kurudisha bidhaa. Ikiwa bidhaa inarudishwa kwa sababu mnunuzi amebadilisha mawazo yake, mnunuzi anaweza kuwajibika kwa gharama za kuirudisha pale ambapo sheria inaruhusu.",

    refundPolicyChangeMindTitle: "Kubadilisha mawazo",
    refundPolicyChangeMindBody: "Kubadilisha mawazo hakukupi moja kwa moja haki ya kurejeshewa fedha au kurudisha bidhaa bila gharama. Haki zozote za kughairi oda au kurudisha bidhaa zitatekelezwa kwa kuzingatia sheria zinazotumika nchini Tanzania, aina ya bidhaa, na masharti husika ya muuzaji.",

    refundPolicyProcessingTitle: "Mchakato wa kurejesha fedha",
    refundPolicyProcessingBody: "Marejesho ya fedha yanapoidhinishwa, Exxabay itaanzisha mchakato wa kurejesha fedha kupitia njia husika ya malipo. Kiasi kinachorejeshwa kinaweza kuwa fedha zote au sehemu ya fedha kulingana na uamuzi wa suala hilo. Muda wa fedha kurejea kwenye akaunti ya mnunuzi unaweza kutegemea mtoa huduma wa malipo au taasisi ya fedha.",

    refundPolicyAfterConfirmationTitle: "Baada ya kuthibitisha oda yako",
    refundPolicyAfterConfirmationBody: "Baada ya kuthibitisha kuwa umepokea oda yako na umeridhika nayo, mchakato wa kawaida wa kushughulikia migogoro ya oda unaweza kutotumika tena kwa malalamiko ya kawaida yanayohusiana na uwasilishaji. Hata hivyo, hitilafu halisi au matatizo mengine yanaweza bado kushughulikiwa chini ya dhamana inayotumika, sera ya muuzaji ya kurudisha bidhaa, haki za mlaji, au suluhisho jingine linalotambuliwa na sheria.",

    refundPolicyFraudulentClaimsTitle: "Madai ya udanganyifu au matumizi mabaya",
    refundPolicyFraudulentClaimsBody: "Exxabay inaweza kuchunguza na kuchukua hatua stahiki pale ambapo kuna ushahidi wa msingi wa udanganyifu au matumizi mabaya ya mfumo wa marejesho ya fedha, ikiwa ni pamoja na kudai kwa uongo kuwa bidhaa haikufika, kurudisha bidhaa tofauti na iliyonunuliwa, kuharibu bidhaa kwa makusudi, au kuwasilisha ushahidi unaopotosha.",

    refundPolicySellerResponsibilityTitle: "Wajibu wa muuzaji",
    refundPolicySellerResponsibilityBody: "Wauzaji wanawajibika kuhakikisha kuwa maelezo ya bidhaa, picha, vipimo, bei, na upatikanaji wa bidhaa ni sahihi na kwamba bidhaa wanazowapatia wanunuzi zinaendana na matangazo yao. Wauzaji pia wanapaswa kuzingatia masharti yanayotumika kuhusu kurudisha bidhaa, dhamana, na ulinzi wa mlaji.",

    refundPolicyExxabayRoleTitle: "Jukumu la Exxabay",
    refundPolicyExxabayRoleBody: "Exxabay inaendesha soko la mtandaoni na hutoa mifumo inayowezesha miamala kati ya wanunuzi na wauzaji waliohakikiwa. Mgogoro unapotokea, Exxabay inaweza kupitia taarifa zilizopo na kusimamia mchakato husika wa ulinzi wa mnunuzi na escrow.",

    refundPolicyApplicableLawTitle: "Sheria zinazotumika",
    refundPolicyApplicableLawBody: "Sera hii inazingatia sheria na kanuni zinazotumika nchini Tanzania. Hakuna sehemu ya sera hii inayokusudia kuondoa au kupunguza haki au suluhisho la mlaji ambalo kisheria haliwezi kuondolewa au kupunguzwa.",

    refundPolicyViewOrders: "Angalia oda zangu",
    refundPolicyContactSupport: "Wasiliana na huduma kwa wateja",
    refundPolicyViewProducts: "Angalia bidhaa",
    
    // FOOTER
    footerAboutExxabay: "Nunua kutoka kwa wauzaji waliothibitishwa kwa kujiamini. Exxabay husaidia wanunuzi kugundua bidhaa huku ikiweka uaminifu wa wauzaji wazi.",
    footerOkVerified: "Wauzaji waliothibitishwa OK",
    secureCheckout: "Malipo Salama",
    buyerProtection: "Ulinzi wa Mnunuzi",
    marketplaceUpdates: "Habari za soko",
    getTrustedDealsAndSellersUpdates: "Pata ofa za kuaminika na masasisho ya wauzaji",
    receiveProductDrops: "Pokea bidhaa mpya, masasisho ya ulinzi wa mnunuzi, na habari za uthibitisho wa wauzaji.",
    emailAdress: "Anwani ya barua pepe",
    enterYourEmail: "Ingiza barua pepe yako",
    subscribe: "Jiandikishe",
    shop: "Duka",
    allProducts: "Bidhaa Zote",
    categories: "Makundi",
    featuredProducts: "Bidhaa Zilizoangaziwa",
    newArrivals: "Bidhaa Mpya",
    sellOnExxabay: "Uza kwenye Exxabay",
    becomeASeller: "Kuwa Muuzaji",
    sellerVerification: "Uthibitisho wa Muuzaji",
    completeSellerProfile: "Kamilisha Wasifu wa Muuzaji",
    sellerGuidelines: "Mwongozo wa Wauzaji",
    customerSupport: "Msaada kwa Wateja",
    helpCenter: "Kituo cha Msaada",
    trackOrder: "Fuatilia Oda",
    returnsAndRefunds: "Marejesho na Fidia",
    contactSupport: "Wasiliana na Msaada",
    trustAndLegal: "Uaminifu na Kisheria",
    sellerVerificationPolicy: "Sera ya Uthibitisho wa Muuzaji",
    privacyPolicy: "Sera ya Faragha",
    termsOfServices: "Masharti ya Huduma",
    reportsASeller: "Ripoti Muuzaji",
    allRightReserved: "2026 Exxabay. Haki zote zimehifadhiwa.",
    callNow: "Piga simu sasa",

    // PRODUCT DETAILS
    backToMarketplace: "Rudi sokoni",
    productInformation: "Taarifa za bidhaa",
    description: "Maelezo",
    sellerCredibility: "Uaminifu wa muuzaji",
    verificationDocuments: "Nyaraka za uthibitisho",
    sellerDocuments: "Nyaraka za muuzaji",
    specifications: "Vipimo",
    productDetails: "Maelezo ya bidhaa",
    noSpecifications: "Hakuna vipimo vya ziada vilivyoongezwa kwa bidhaa hii bado.",
    stock: "Hisa",
    availability: "Upatikanaji",
    listed: "Imeorodheshwa",
    available: "Inapatikana",
    unavailable: "Haipatikani",
    addToCart: "Ongeza Kikapuni",
    continueShopping: "Endelea Kununua",
    lowStock: "Inakaribia Kuisha",
    inStock: "Ipo Dukani",
    featured: "Imeangaziwa",
    okVerified: "OK Imethibitishwa",
    pendingStatus: "! Inasubiri",
    unverifiedStatus: "X Haijathibitishwa",
    verifiedSellerCopy: "Muuzaji huyu amethibitishwa na Exxabay na anakidhi viwango vyetu vya uaminifu.",
    pendingSellerCopy: "Muuzaji huyu amewasilisha taarifa muhimu za uaminifu na anasubiri ukaguzi wa Exxabay.",
    unverifiedSellerCopy: "Muuzaji huyu bado hajakamilisha ukaguzi wa uthibitisho wa Exxabay.",
    totalProducts: "Jumla ya bidhaa",
    completedOrders: "Oda zilizokamilika",
    rating: "Alama",
    businessLicenseDoc: "Leseni ya Biashara",
    taxClearanceDoc: "Nyaraka ya Ulipaji Kodi",
    idTinVerification: "Uthibitisho wa Kitambulisho / TIN",
    storeRegistration: "Usajili wa Duka",
    onFileSubmitted: "Ipo - Imewasilishwa",
    notSubmittedMissing: "Haijawasilishwa - Haipo",
    tinOnFile: "TIN ipo - Imewasilishwa",
    businessProfileOnFile: "Wasifu wa biashara ipo - Imewasilishwa",
    viewDocument: "Inapatikana unapohitaji",
    uncategorized: "Bila Kundi",

    // CART
    secureMarketplaceCart: "Kikapu salama cha soko",
    yourShoppingCart: "Kikapu chako cha ununuzi",
    cartHeroCopy: "Kagua maelezo ya wauzaji, idadi, na jumla kabla ya kulipa kwa simu.",
    trustProtectedCheckout: "Malipo yaliyolindwa na uaminifu",
    trustProtectedCheckoutCopy: "Uthibitisho wa muuzaji unabaki wazi katika safari yako yote ya oda.",
    marketplaceOrder: "Oda ya soko",
    itemsInYourCart: "Bidhaa zilizo kikapuni",
    cartProductsBySellers: "Bidhaa za kikapu kutoka kwa wauzaji",
    sellerLabel: "Muuzaji:",
    price: "Bei",
    quantity: "Idadi",
    subtotal: "Jumla ndogo",
    remove: "Ondoa",
    orderSummary: "Muhtasari wa oda",
    cartTotal: "Jumla ya kikapu",
    itemsSubtotal: "Jumla ndogo ya bidhaa",
    delivery: "Uwasilishaji",
    calculatedAtCheckout: "Itahesabiwa wakati wa malipo",
    trustProtection: "Ulinzi wa uaminifu",
    included: "Imejumuishwa",
    total: "Jumla",
    proceedToCheckout: "Endelea kwa Malipo",
    mobileMoneySupported: "Malipo ya simu yanakubaliwa",
    mobileMoneyNote: "Lipa salama kwa M-Pesa, Tigo Pesa, Airtel Money, wakati wa malipo.",
    cartEmpty: "Kikapu chako kipo tupu",
    cartEmptyCopy: "Anza kuchunguza bidhaa za kuaminika kutoka kwa wauzaji waliothibitishwa kwenye Exxabay.",
    decreaseQuantity: "Punguza idadi",
    increaseQuantity: "Ongeza idadi",
    Charges: "Ada",
    AmountPayable: "Kiasi cha kulipa",
    PaymentPhoneNumber: "Namba ya simu ya malipo",

    // ORDER DETAILS
    awaitingPayment: "Inasubiri malipo",
    paymentConfirmed: "Malipo yamethibitishwa",
    paymentFailed: "Malipo yameshindwa",
    orderTitle: "Oda #",
    awaitingPaymentCopy: "Ombi la malipo limetumwa kwa simu yako. Tafadhali idhibiti ili kukamilisha oda yako.",
    paymentConfirmedCopy: "Malipo yako ya simu yamefanikiwa. Hapa chini ni muhtasari wa oda yako ya soko.",
    paymentFailedCopy: "Malipo yako hayakukamilika. Kikapu chako hakijaathiriwa, unaweza jaribu tena hapa chini.",
    waitingForConfirmation: "Inasubiri uthibitisho",
    checkYourPhone: "Angalia simu yako kwa ujumbe wa USSD na weka PIN yako.",
    checkoutCompleted: "Malipo yamekamilika",
    checkoutCompletedCopy: "Rekodi za uaminifu wa muuzaji na malipo zimeambatishwa kwenye oda hii.",
    paymentUnsuccessful: "Malipo hayakufanikiwa",
    paymentUnsuccessfulCopy: "Hakuna pesa iliyotozwa. Tafadhali jaribu tena au tumia nambari nyingine.",
    tryAgain: "Jaribu Tena",
    orderItems: "Bidhaa za oda",
    purchasedProducts: "Bidhaa zilizonunuliwa",
    unitPrice: "Bei ya kitengo",
    noOrderItems: "Hakuna bidhaa za oda zilizopatikana",
    noOrderItemsCopy: "Oda hii haina bidhaa zozote zilizounganishwa.",
    receipt: "Risiti",
    orderSummaryTitle: "Muhtasari wa oda",
    statusLabel: "Hali",
    paymentMethod: "Njia ya malipo",
    paymentStatus: "Hali ya malipo",
    transactionId: "Nambari ya muamala",
    totalPaid: "Jumla iliyolipwa",
    mobileMoneyThankYou: "Mchakato wa malipo umerahisishwa kwenye simu yako",
    mobileMoney: "Malipo ya simu",

    // SELLER ANALYTICS
    sellerAnalytics: "Uchambuzi wa muuzaji",
    businessPerformanceCenter: "Kituo cha utendaji wa biashara",
    businessPerformanceCopy: "Elewa mapato, afya ya oda, tabia za wanunuzi, hatari ya hesabu, na bidhaa bora kutoka sehemu moja ya muuzaji.",
    verifiedSellerAnalytics: "Uchambuzi wa muuzaji aliyethibitishwa",
    analyticsVisiblePending: "Uchambuzi unaonekana wakati uthibitisho unaendelea",
    performanceOverview: "Muhtasari wa utendaji",
    businessAnalysis: "Uchambuzi wa biashara",
    analyticsDateFilter: "Chuja tarehe za uchambuzi",
    fromDate: "Tarehe ya kuanzia",
    toDate: "Tarehe ya kuishia",
    applyFilter: "Tumia kichujio",
    clearFilter: "Futa",
    keyBusinessMetrics: "Vipimo vikuu vya biashara",
    keyBusinessMetricsCopy: "Mapato na afya ya oda kwa kipindi kilichochaguliwa.",
    revenueLabel: "Mapato",
    ordersLabel: "Oda",
    aovLabel: "AOV",
    riskLabel: "Hatari",
    grossRevenue: "Mapato Ghafi",
    paidActiveOrders: "Oda Zilizolipwa / Zinazoendelea",
    averageOrderValue: "Wastani wa Thamani ya Oda",
    cancellationRate: "Kiwango cha Kufuta",
    orderHealth: "Afya ya oda",
    orderHealthCopy: "Fuatilia oda zilizolipwa, maendeleo ya utekelezaji, na utendaji wa ukamilishaji.",
    pendingOrders: "Zinasubiri",
    paidOrders: "Zilizolipwa",
    processingOrders: "Zinashughulikiwa",
    completedOrders: "Zilizokamilika",
    completedRate: "Kiwango cha kukamilika",
    unitsSold: "Vitengo vilivyouzwa",
    recentSalesTrend: "Mwenendo wa mauzo ya hivi karibuni",
    recentSalesTrendCopy: "Siku za mwisho za mauzo katika kipindi kilichochaguliwa.",
    noSalesTrend: "Hakuna mwenendo wa mauzo bado",
    noSalesTrendCopy: "Mauzo yaliyolipwa, yanayoshughulikiwa, na kukamilika yataonekana hapa.",
    topProducts: "Bidhaa bora",
    topProductsCopy: "Bidhaa zenye utendaji bora kwa mapato.",
    productCol: "Bidhaa",
    categoryCol: "Kundi",
    ordersCol: "Oda",
    unitsCol: "Vitengo",
    revenueCol: "Mapato",
    stockCol: "Hisa",
    outOfStock: "Hisa imeisha",
    noProductData: "Hakuna data ya utendaji wa bidhaa zilizolipwa bado.",
    actionQueue: "Foleni ya hatua",
    actionQueueCopy: "Oda zinazohitaji umakini wa muuzaji kwanza.",
    callBuyer: "Mpigie mnunuzi simu",
    noUrgentOrders: "Hakuna oda za haraka",
    noUrgentOrdersCopy: "Oda zinazosubiri, zilizolipwa, na zinazoshughulikiwa zitaonekana hapa.",
    businessSnapshot: "Picha ya biashara",
    sellerHealth: "Afya ya muuzaji",
    productsLabel: "Bidhaa",
    activeProducts: "Bidhaa zinazofanya kazi",
    lowStockLabel: "Hisa ndogo",
    outOfStockLabel: "Hisa imeisha",
    featuredLabel: "Zilizoangaziwa",
    inventoryValue: "Thamani ya hisa",
    uniqueBuyers: "Wanunuzi wa kipekee",
    repeatBuyers: "Wanunuzi wanaorudia",
    sellerStatusLabel: "Hali ya muuzaji",
    completionRateLabel: "Kiwango cha kukamilika",
    cancelledOrders: "Oda zilizofutwa",
    verifiedStatus: "Imethibitishwa",
    pendingReview: "Inasubiri ukaguzi",
    reviewPaidOrders: "Kagua oda zilizolipwa",
    openOrders: "Fungua oda",
    analysisNote: "Kumbuka uchambuzi",
    analysisNoteCopy: "Mapato yanatumia mistari ya oda ya muuzaji iliyolipwa, inayoshughulikiwa, na kukamilika. Oda zinazosubiri na zilizofutwa zinaonyeshwa kwa ufahamu wa uendeshaji.",
    noCategoryData: "Hakuna data ya kundi bado",
    noCategoryDataCopy: "Utendaji wa kundi unaonekana baada ya mauzo yaliyolipwa.",
    noStatusData: "Hakuna data ya hali",
    noStatusDataCopy: "Muhtasari wa hali ya oda utaonekana hapa.",

    // SELLER ORDERS
    sellerOrderCenter: "Kituo cha oda za muuzaji",
    ordersSoldOnExxabay: "Oda zilizouzwa kwenye Exxabay",
    sellerOrderCenterCopy: "Fuatilia oda zilizolipwa, utekelezaji unaosuba, maelezo ya wanunuzi, historia ya bidhaa, na mapato ya muuzaji kutoka sehemu moja.",
    verifiedSellerProfile: "Wasifu wa muuzaji aliyethibitishwa",
    sellerVerificationInProgress: "Uthibitisho wa muuzaji unaendelea",
    orderHistory: "Historia ya oda",
    soldProducts: "Bidhaa zilizouzwa",
    sellerOrderItems: "Bidhaa za oda za muuzaji",
    buyerLabel: "Mnunuzi:",
    emailBuyer: "Mtumie mnunuzi barua pepe",
    noPhoneNumber: "Hakuna nambari ya simu",
    sellerSubtotal: "Jumla ndogo ya muuzaji",
    noSellerOrders: "Hakuna oda za muuzaji bado",
    noSellerOrdersCopy: "Oda za bidhaa zako zitaonekana hapa baada ya wanunuzi kukamilisha malipo.",
    okCompleted: "OK Imekamilika",
    sellerSummary: "Muhtasari wa muuzaji",
    orderPerformance: "Utendaji wa oda",
    totalRevenue: "Jumla ya mapato",
    uniqueOrders: "Oda za kipekee",
    pendingActive: "Zinasubiri / zinazoendelea",
    fulfillmentFocus: "Lengo la utekelezaji",
    fulfillmentFocusCopy: "Oda zilizolipwa na zinazosubiri",
    paymentMode: "Njia ya malipo",
    paymentModeCopy: "Malipo ya simu",
    viewPaidOrders: "Tazama oda zilizolipwa",
    viewAllHistory: "Tazama historia yote",

    // BUYER DASHBOARD
    buyerAccount: "Akaunti ya mnunuzi",
    accountWelcome: "Karibu,",
    accountHeroCopy: "Simamia oda zako, sasisha maelezo yako, na fuatilia shughuli zako za soko.",
    trustProtectedAccount: "Akaunti iliyolindwa kwa uaminifu",
    trustProtectedAccountCopy: "Manunuzi yako yanalindwa na mfumo wa uthibitisho wa wauzaji wa Exxabay.",
    totalOrders: "Jumla ya oda",
    completedOrders: "Zilizokamilika",
    pendingPayment: "Malipo yanayosubiri",
    actionRequired: "Hatua inahitajika",
    pendingPayments: "Malipo yanayosubiri",
    pendingCount: "zinasubiri",
    orderHistoryEyebrow: "Historia ya oda",
    allOrders: "Oda zote",
    totalCount: "jumla",
    payNow: "Lipa sasa →",
    viewOrder: "Tazama",
    totalLabel: "Jumla",
    okPaid: "OK Imelipwa",
    okDelivered: "OK Imewasilishwa",
    shippedStatus: "⟶ Imepelekwa",
    cancelledStatus: "X Imefutwa",
    noOrdersYet: "Hakuna oda bado",
    noOrdersCopy: "Bado hujaweka oda yoyote. Chunguza wauzaji wa kuaminika na uanze kununua.",
    browseProducts: "Vinjari bidhaa",
    personalDetails: "Maelezo ya kibinafsi",
    editAccount: "Hariri akaunti",
    firstName: "Jina la kwanza",
    lastName: "Jina la familia",
    emailAddress: "Anwani ya barua pepe",
    phoneNumber: "Nambari ya simu",
    usernameLabel: "Jina la mtumiaji",
    changePassword: "Badilisha nenosiri",
    newPassword: "Nenosiri jipya",
    confirmPassword: "Thibitisha nenosiri",
    leaveBlankPassword: "Acha wazi ili kubaki na nenosiri lako la sasa.",
    saveChanges: "Hifadhi mabadiliko",
    cancelButton: "Ghairi",
    growWithExxabay: "Kukua na Exxabay",
    startSelling: "Anza kuuza kwenye Exxabay",
    startSellingCopy: "Jiunge na maelfu ya wauzaji waliothibitishwa. Orodhesha bidhaa zako, fikia wanunuzi wa kuaminika, na kukuza biashara yako.",
    verifiedListings: "✓ Matangazo yaliyothibitishwa",
    mobileMoneyPayouts: "✓ Malipo ya simu",
    sellerDashboardPill: "✓ Dashibodi ya muuzaji",
    freeToRegister: "✓ Bure kusajili",
    becomeSellerCta: "Kuwa muuzaji →",
    memberSince: "Mwanachama tangu",
    phoneLabel: "Simu",
    usernameField: "Jina la mtumiaji",
    ordersField: "Oda",
    signOut: "Toka",
    hereForYou: "Tuko hapa kwa ajili yako",
    talkToExxabay: "Zungumza na Exxabay",
    callUsDirectly: "Tupigie simu moja kwa moja",
    callHours: "Jumatatu–Jumamosi, 8asubuhi–6jioni EAT",
    whatsappSupport: "Msaada wa WhatsApp",
    whatsappCopy: "Majibu ya haraka kwa maswala ya oda.",
    openWhatsapp: "Fungua WhatsApp",
    emailSupport: "Msaada wa barua pepe",
    sendEmail: "Tuma barua pepe",


    // FOOTER PAGES POLICY, TERMS OF SERVICES
    navLabel: "Urambazaji mkuu",
    searchProducts: "Tafuta bidhaa za Exxabay",
    navSearchPlaceholder: "Tafuta bidhaa, chapa, na wauzaji wa kuaminika",
    heroSearchPlaceholder: "Unatafuta nini leo?",
    search: "Tafuta",
    viewCart: "Tazama kikapu",
    openProfile: "Fungua wasifu",
    switchLanguage: "Badilisha lugha kwenda Kiingereza",
    heroEyebrow: "Soko linalotanguliza uaminifu",
    heroTitle: "Nunua kutoka kwa wauzaji waliothibitishwa kwa kujiamini",
    heroCopy: "Gundua mahitaji ya kila siku, elektroniki, mitindo, na bidhaa za nyumbani zikiwa na uthibitisho wa muuzaji kwenye kila tangazo.",
    popularCategories: "Makundi maarufu",
    catElectronics: "Elektroniki",
    catHome: "Nyumbani",
    catFashion: "Mitindo",
    catBeauty: "Urembo",
    trustSummary: "Muhtasari wa uaminifu wa soko",
    trustSignalTitle: "Ishara za muuzaji aliyethibitishwa",
    trustSignalCopy: "Ukaguzi wa biashara, hali ya nyaraka, na takwimu za oda huonekana kabla ya kununua.",
    averageRating: "Wastani wa alama za wauzaji",
    completedTrustedOrders: "Oda salama zilizokamilika",
    featuredMarketplace: "Soko lililoangaziwa",
    productsTitle: "Bidhaa kutoka kwa wauzaji wa kuaminika",
    filterSellers: "Chuja wauzaji",
    seller: "Muuzaji",
    viewSellerTrust: "Tazama Uaminifu wa Muuzaji",
    addToCart: "Ongeza Kikapuni",
    viewDetails: "Tazama Maelezo",
    inStock: "Ipo dukani",
    lowStock: "Inakaribia kuisha",
    verified: "Imethibitishwa",
    pending: "Inasubiri",
    unverified: "Haijathibitishwa",
    sellerTrustProfile: "Wasifu wa uaminifu wa muuzaji",
    verificationStatus: "Hali ya Uthibitisho",
    documents: "Nyaraka",
    sensitivePreviewsHidden: "Muonekano wa taarifa nyeti umefichwa",
    sellerMetrics: "Takwimu za Muuzaji",
    totalProducts: "Jumla ya bidhaa",
    completedOrders: "Oda zilizokamilika",
    rating: "Alama",
    closeTrustDetails: "Funga maelezo ya uaminifu wa muuzaji",
    viewDocument: "Inapatikana unapohitaji",
    stars: "nyota",
    businessLicense: "Leseni ya Biashara",
    idVerification: "Uthibitisho wa Kitambulisho",
    storeRegistration: "Usajili wa Duka",
    taxClearance: "Nyaraka ya Ulipaji Kodi",
    noProductsTitle: "Hakuna bidhaa zilizopo",
    noProductsCopy: "Tafadhali rudi tena hivi karibuni kwa matangazo ya soko la kuaminika.",
    submitted: "Imewasilishwa",
    missing: "Haipo",
    unavailable: "Haipatikani",
    trustCopyVerified: "Muuzaji huyu amethibitishwa na Exxabay na anakidhi viwango vyetu vya uaminifu.",
    trustCopyPending: "Muuzaji huyu amewasilisha taarifa muhimu za wasifu wa uaminifu na anasubiri ukaguzi wa Exxabay.",
    trustCopyUnverified: "Muuzaji huyu bado hajakamilisha ukaguzi wa uthibitisho wa Exxabay.",
    policyHeroTrustCopy: "Sera za Exxabay zimejengwa kwa ajili ya mahusiano salama kati ya wanunuzi na wauzaji.",
    exabayPolicy: "Sera ya Exxabay",
    sectionsLabel: "sehemu",
    trustCenter: "Kituo cha uaminifu",
    relatedActions: "Hatua zinazohusiana",
    policyLabel: "Sera",
    focusLabel: "Lengo",
    marketplaceLabel: "Soko",
    importantNote: "Taarifa muhimu",
    policyImportantNoteCopy: "Ukurasa huu unatoa mwongozo wa soko. Exxabay inaweza kuboresha sera kadri bidhaa, malipo, na mahitaji ya wauzaji yanavyobadilika.",
    buyerProtectionEyebrow: "Nunua kwa kujiamini",
    buyerProtectionTitle: "Ulinzi wa Mnunuzi",
    buyerProtectionSummary: "Exxabay huwasaidia wanunuzi kununua kwa usalama kwa kuunganisha ishara za wauzaji waliothibitishwa, malipo salama, na ufuatiliaji wa oda.",
    buyerProtectionBadge: "Usalama wa mnunuzi",
    buyerProtectionSection1Title: "Muonekano wa muuzaji aliyethibitishwa",
    buyerProtectionSection1Body: "Kurasa za bidhaa na kadi za wauzaji huonyesha hali ya uthibitisho ili mnunuzi aelewe haraka kama muuzaji amekamilisha ukaguzi wa uaminifu wa Exxabay.",
    buyerProtectionSection2Title: "Mchakato salama wa malipo",
    buyerProtectionSection2Body: "Wanunuzi wanapaswa kulipa kupitia njia rasmi zinazoungwa mkono na Exxabay. Wauzaji hawapaswi kuomba PIN, nywila, au uthibitisho wa malipo nje ya mfumo.",
    buyerProtectionSection3Title: "Ufuatiliaji wa oda",
    buyerProtectionSection3Body: "Oda zilizolipiwa zinaweza kufuatiliwa na wasimamizi wa Exxabay ili kusaidia wauzaji na wanunuzi kuratibu uwasilishaji na uthibitisho wa kupokea bidhaa.",
    buyerProtectionSection4Title: "Mchakato wa kuripoti na kukagua",
    buyerProtectionSection4Body: "Ikiwa bidhaa inapotosha, haijawasilishwa, au inahusishwa na tabia ya kutiliwa shaka ya muuzaji, mnunuzi anaweza kuwasilisha ripoti ya muuzaji kwa ukaguzi.",
    buyerProtectionAction1: "Ripoti muuzaji",
    buyerProtectionAction2: "Tazama bidhaa",
    sellerVerificationPolicyEyebrow: "Uaminifu wa soko",
    sellerVerificationPolicyTitle: "Sera ya Uthibitishaji wa Wauzaji",
    sellerVerificationPolicySummary: "Exxabay huthibitisha utambulisho wa muuzaji na taarifa za biashara kabla ya kumpa muuzaji upatikanaji kamili wa soko la kuaminika.",
    sellerVerificationPolicyBadge: "Uthibitishaji",
    sellerVerificationPolicySection1Title: "Taarifa za biashara zinazohitajika",
    sellerVerificationPolicySection1Body: "Wauzaji wanaweza kuombwa kutoa jina la biashara, namba ya TIN, leseni ya biashara, tarehe ya mwisho wa leseni, na taarifa nyingine za kodi au usajili.",
    sellerVerificationPolicySection2Title: "Ukaguzi wa msimamizi",
    sellerVerificationPolicySection2Body: "Wasimamizi wa Exxabay hukagua taarifa zilizowasilishwa na wanaweza kuthibitisha, kukataa, au kuomba marekebisho kabla hali ya uaminifu haijaonyeshwa kwa wanunuzi.",
    sellerVerificationPolicySection3Title: "Faragha ya nyaraka",
    sellerVerificationPolicySection3Body: "Nyaraka za uthibitisho hutumika kwa ukaguzi wa uaminifu wa soko na hazionyeshwi kama muonekano wa taarifa nyeti kwenye kurasa za bidhaa.",
    sellerVerificationPolicySection4Title: "Ukaguzi endelevu wa uaminifu",
    sellerVerificationPolicySection4Body: "Hali ya uthibitisho inaweza kuondolewa ikiwa muuzaji atatoa taarifa zisizo sahihi, atakiuka sheria za soko, au hatadumisha nyaraka halali.",
    sellerVerificationPolicyAction1: "Kamilisha wasifu wa muuzaji",
    sellerVerificationPolicyAction2: "Miongozo ya wauzaji",
    privacyPolicyEyebrow: "Data na uaminifu",
    privacyPolicyTitle: "Sera ya Faragha",
    privacyPolicySummary: "Exxabay hukusanya taarifa zinazohitajika tu kuendesha akaunti, oda, uthibitishaji wa wauzaji, malipo, malipo kwa wauzaji, na msaada wa soko.",
    privacyPolicyBadge: "Faragha",
    privacyPolicySection1Title: "Taarifa tunazokusanya",
    privacyPolicySection1Body: "Tunaweza kukusanya taarifa za akaunti, mawasiliano, rekodi za oda, rejea za malipo, nyaraka za biashara za muuzaji, na ujumbe wa msaada.",
    privacyPolicySection2Title: "Jinsi taarifa zinavyotumika",
    privacyPolicySection2Body: "Taarifa hutumika kusimamia akaunti, kuchakata oda, kuthibitisha wauzaji, kusaidia malipo na malipo kwa wauzaji, kuzuia udanganyifu, na kutuma taarifa za soko.",
    privacyPolicySection3Title: "Kushirikisha na usalama",
    privacyPolicySection3Body: "Exxabay inaweza kushirikisha taarifa muhimu za muamala na watoa huduma za malipo na washirika wa uendeshaji. Nyaraka nyeti za muuzaji zinapaswa kulindwa na kufikiwa na watumiaji walioidhinishwa tu.",
    privacyPolicySection4Title: "Chaguo zako",
    privacyPolicySection4Body: "Watumiaji wanaweza kusasisha taarifa za akaunti, mapendeleo ya arifa, na mipangilio ya muuzaji kwenye kurasa zao za akaunti pale inapopatikana.",
    privacyPolicyAction1: "Mipangilio ya akaunti",
    privacyPolicyAction2: "Wasiliana na msaada",
    termsOfServiceEyebrow: "Sheria za soko",
    termsOfServiceTitle: "Masharti ya Huduma",
    termsOfServiceSummary: "Masharti haya yanaeleza majukumu ya wanunuzi, wauzaji, na Exxabay wakati wa kutumia soko.",
    termsOfServiceBadge: "Masharti",
    termsOfServiceSection1Title: "Wajibu wa akaunti",
    termsOfServiceSection1Body: "Watumiaji wanawajibika kulinda taarifa za kuingia na kutoa taarifa sahihi za usajili, mawasiliano, na muuzaji.",
    termsOfServiceSection2Title: "Jukumu la soko",
    termsOfServiceSection2Body: "Exxabay hutoa jukwaa la soko kwa ugunduzi wa bidhaa, malipo, uthibitishaji wa wauzaji, ufuatiliaji wa oda, na msaada wa malipo kwa wauzaji.",
    termsOfServiceSection3Title: "Majukumu ya muuzaji",
    termsOfServiceSection3Body: "Wauzaji wanapaswa kuweka bidhaa kwa usahihi, kudumisha taarifa za stoo, kutimiza oda zilizolipiwa, kuwasiliana kitaalamu, na kufuata mahitaji ya uthibitishaji.",
    termsOfServiceSection4Title: "Majukumu ya mnunuzi",
    termsOfServiceSection4Body: "Wanunuzi wanapaswa kutoa taarifa sahihi za oda na mawasiliano, kukamilisha malipo kupitia njia zinazoungwa mkono, na kuepuka matumizi mabaya au udanganyifu.",
    termsOfServiceSection5Title: "Utekelezaji wa sera",
    termsOfServiceSection5Body: "Exxabay inaweza kuzuia akaunti, kuondoa matangazo, kukataa uthibitishaji, kusitisha malipo kwa wauzaji, au kufuta oda pale usalama wa soko unapohitaji.",
    termsOfServiceAction1: "Ulinzi wa mnunuzi",
    termsOfServiceAction2: "Miongozo ya wauzaji",
    sellerGuidelinesEyebrow: "Uza kwa uwajibikaji",
    sellerGuidelinesTitle: "Miongozo ya Wauzaji",
    sellerGuidelinesSummary: "Miongozo hii huwasaidia wauzaji kujenga uaminifu wa wanunuzi, kupunguza migogoro, na kudumisha utendaji mzuri wa soko.",
    sellerGuidelinesBadge: "Viwango vya muuzaji",
    sellerGuidelinesSection1Title: "Matangazo sahihi",
    sellerGuidelinesSection1Body: "Majina ya bidhaa, picha, maelezo, vipimo, bei, na idadi ya stoo vinapaswa kuwa vya kweli na kusasishwa mara kwa mara.",
    sellerGuidelinesSection2Title: "Uwasilishaji wa kuaminika",
    sellerGuidelinesSection2Body: "Wauzaji wanapaswa kuandaa oda zilizolipiwa kwa wakati, kuwasiliana wazi na wanunuzi, na kusasisha hali ya utimizaji inapobadilika.",
    sellerGuidelinesSection3Title: "Mawasiliano ya kitaalamu",
    sellerGuidelinesSection3Body: "Wauzaji lazima wawasiliane kwa heshima na hawapaswi kuomba taarifa nyeti za malipo au kuhamisha wanunuzi nje ya njia salama za malipo.",
    sellerGuidelinesSection4Title: "Uaminifu na uthibitishaji",
    sellerGuidelinesSection4Body: "Nyaraka za biashara na taarifa za malipo kwa muuzaji zinapaswa kubaki sahihi. Rekodi zilizokwisha muda au zisizo sahihi zinaweza kuchelewesha uthibitishaji au malipo.",
    sellerGuidelinesSection5Title: "Utayari wa malipo kwa muuzaji",
    sellerGuidelinesSection5Body: "Malipo kwa wauzaji hutegemea mapato yanayostahili baada ya kamisheni ya soko na hutegemea taarifa sahihi za malipo na utimizaji uliokamilika.",
    sellerGuidelinesAction1: "Mipangilio ya muuzaji",
    sellerGuidelinesAction2: "Sera ya uthibitishaji",
    reportSellerEyebrow: "Usalama wa soko",
    reportSellerTitle: "Ripoti muuzaji",
    reportSellerSummary: "Mjulishe Exxabay kuhusu tabia ya kutiliwa shaka ya muuzaji, bidhaa zinazopotosha, changamoto za uwasilishaji, au masuala ya uaminifu.",
    reportSellerTrustCopy: "Ripoti husaidia Exxabay kukagua wauzaji na kudumisha maana ya ishara za uaminifu sokoni.",
    safetyReport: "Ripoti ya usalama",
    sellerReportDetails: "Maelezo ya ripoti ya muuzaji",
    supportReview: "Ukaguzi wa msaada",
    reportStatus: "Hali ya ripoti",
    reportSellerNameLabel: "Jina la muuzaji au duka",
    reportOrderIdLabel: "Namba ya oda",
    optionalLabel: "Si lazima",
    reportEmailLabel: "Barua pepe yako",
    reportReasonLabel: "Sababu",
    reportDetailsLabel: "Nini kimetokea?",
    reportEvidenceLabel: "Kiungo cha ushahidi",
    submitReport: "Wasilisha ripoti",
    beforeSubmitting: "Kabla ya kuwasilisha",
    helpfulDetails: "Taarifa muhimu",
    includeLabel: "Jumuisha",
    includeReportDetails: "Jina la muuzaji, namba ya oda, bidhaa, na mfululizo wa matukio",
    avoidLabel: "Epuka",
    avoidReportDetails: "Nywila, PIN, na taarifa nyeti za malipo",
    reviewLabel: "Ukaguzi",
    reviewReportDetails: "Msaada wa Exxabay hukagua ripoti kwa ajili ya hatari za soko",
    urgentSafetyIssue: "Tatizo la haraka la usalama?",
    urgentSafetyIssueCopy: "Ikiwa fedha au upatikanaji wa akaunti uko hatarini mara moja, wasiliana moja kwa moja na msaada wa Exxabay pamoja na kuwasilisha ripoti hii.",
    reportSellerNamePlaceholder: "Jina la muuzaji au duka",
    reportOrderIdPlaceholder: "Namba ya oda, ikiwa ipo",
    reportEmailPlaceholder: "Barua pepe yako",
    reportDetailsPlaceholder: "Eleza kilichotokea. Usiweke nywila, PIN, au taarifa nyeti za malipo.",
    reportEvidencePlaceholder: "Kiungo cha ushahidi, si lazima",
    reportReason_fake_product: "Bidhaa bandia au inayopotosha",
    reportReason_fraud: "Udanganyifu au ombi la malipo la kutiliwa shaka",
    reportReason_non_delivery: "Bidhaa haijawasilishwa",
    reportReason_poor_communication: "Mawasiliano mabaya au yasiyo salama",
    reportReason_document_trust: "Wasiwasi kuhusu uaminifu wa muuzaji",
    reportReason_other: "Nyingine",


    // EXXABAY GO
    howItWorksEyebrow: "Inafanyaje kazi",
    howItWorksTitle: "Rahisi. Salama. Papo hapo.",

    howStep1Title: "Omba na uthibitishwe",
    howStep1Desc: "Wasilisha TIN, leseni ya biashara, kitambulisho cha taifa, na picha za duka lako. Unathibitishwa ndani ya saa 48.",

    howStep2Title: "Ongeza bidhaa au tumia Exxabay Go",
    howStep2Desc: "Ongeza bidhaa sokoni au tengeneza link salama za malipo kwa wateja wa WhatsApp na Instagram.",

    howStep3Title: "Mteja analipa kwa usalama",
    howStep3Desc: "Malipo kupitia M-Pesa, Airtel Money, Halopesa, au Mixx by Yas.",

    howStep4Title: "Pokea pesa papo hapo",
    howStep4Desc: "Soko: Pata malipo mara moja. Exxabay Go: mteja analipa ada ndogo, wewe unapokea 100% ya makubaliano.",

    whyExxabayEyebrow: "Kwa nini Exxabay",
    whyExxabayTitle: "Uaminifu ndani ya kila muamala",

    whyCard1Title: "Kila muuzaji anathibitishwa",
    whyCard1Desc: "TIN, leseni ya biashara, kitambulisho cha taifa, na anwani ya duka vinathibitishwa kabla ya muuzaji kuanza.",

    whyCard2Title: "Exxabay Go",
    whyCard2Desc: "Pokea malipo kutoka WhatsApp na Instagram kupitia link salama na iliyothibitishwa.",

    whyCard3Title: "Uwajibikaji wa kisheria",
    whyCard3Desc: "Kama muuzaji atakudanganya, tunatoa taarifa zake zote kwa polisi kuchukua hatua. Hakuna kujificha.",

    whyCard4Title: "Hakuna gharama za awali",
    whyCard4Desc: "Hakuna ada ya kujiunga au ya kila mwezi.",

    "exxabayGo.hero.badge": "EXXABAY GO",
  "exxabayGo.hero.new": "MPYA",
  "exxabayGo.hero.title": "Uza popote. Pokea malipo kwa usalama.",
  "exxabayGo.hero.description":
    "Unauza kupitia WhatsApp, Instagram, au Facebook? Exxabay Go inawawezesha wauzaji waliothibitishwa kutuma link salama ya malipo kwa mteja yeyote bila kuweka bidhaa sokoni. Ada ni Tsh 1,500 + 1% kwa kila muamala.",

  "exxabayGo.hero.platform.whatsapp": "WhatsApp",
  "exxabayGo.hero.platform.instagram": "Instagram",
  "exxabayGo.hero.platform.facebook": "Facebook",
  "exxabayGo.hero.platform.sms": "SMS",

  "exxabayGo.hero.cta": "Jifunze zaidi kuhusu Exxabay Go",
  "exxabayGo.hero.note": "Inapatikana kwa wauzaji waliothibitishwa wa Exxabay pekee",

  "exxabayGo.hero.step1": "Muuzaji anaweka namba ya mteja + kiasi",
  "exxabayGo.hero.step2": "Exxabay inatengeneza link salama ya malipo",
  "exxabayGo.hero.step3": "Mteja analipa kupitia M-Pesa, Airtel, Halopesa au Mixx",
  "exxabayGo.hero.step4": "Muuzaji anapokea 100% ya malipo mara moja",


  // EXXABAY GO LANDING PAGE
  "hero.eyebrow": "Exxabay Go",
    "hero.title_line1": "Uza popote.",
    "hero.title_line2": "Pokea malipo kwa usalama.",
    "hero.subtitle": "Kifaa cha malipo kinachobebeka kwa wauzaji waliothibitishwa wa Exxabay. Tuma kiungo cha malipo salama chenye chapa yako kwa mteja yeyote kupitia WhatsApp, Instagram, au SMS bila kuhitaji tangazo la bidhaa sokoni.",
    "hero.note": "Inapatikana kwa wauzaji waliothibitishwa wa Exxabay pekee",
    "common.dashboard_cta": "Nenda kwenye dashibodi ya muuzaji",
    "stats.fee_label": "Ada ya msingi kwa kila kiungo",
    "stats.percent_label": "Ya kiasi cha muamala",
    "stats.instant": "Papo hapo",
    "stats.payout_label": "Malipo kwa muuzaji",
    "how.eyebrow": "Jinsi inavyofanya kazi",
    "how.title": "Hatua tatu za malipo salama",
    "how.step1_title": "Weka namba ya WhatsApp ya mteja na kiasi",
    "how.step1_desc": "Fungua Exxabay Go kutoka dashibodi yako ya muuzaji. Sehemu mbili tu namba ya simu na kiasi. Ada inahesabiwa na kufungwa mara tu unapotengeneza kiungo.",
    "how.step2_title": "Tuma kiungo cha malipo",
    "how.step2_desc": "Bofya \"Tuma kupitia WhatsApp\" kiungo kinakwenda moja kwa moja kwa mteja wako pamoja na ujumbe wa Kiswahili ulioandaliwa tayari. Au tuma kupitia SMS. Kiungo kinaonyesha jina lako la biashara lililothibitishwa na kiasi halisi ambacho mteja anapaswa kulipa.",
    "how.step3_title": "Mteja analipa, unapokea fedha papo hapo",
    "how.step3_desc": "Mteja wako analipa kutoka namba yoyote ya pesa za simu anayochagua M-Pesa, Airtel Money, Halopesa, au Mixx by Yas. Unapokea 100% ya kiasi kilichokubaliwa. Ada ndogo ya Exxabay Go inalipwa na mteja juu ya kiasi hicho.",
    "fee.eyebrow": "Muundo wa ada",
    "fee.title": "Rahisi na wazi",
    "fee.formula": "Tsh 1,500 + 1% ya kiasi cha muamala",
    "fee.row_seller_enters": "Kiasi alichoweka muuzaji",
    "fee.row_fee": "Ada ya Exxabay Go (analipa mteja)",
    "fee.row_total": "Jumla analolipa mteja",
    "fee.row_receives": "Muuzaji anapokea",
    "fee.note": "Ada hulipwa na mteja, si muuzaji. Inafungwa kabisa wakati wa kutengeneza kiungo. Muuzaji hupokea kila mara kiasi kilichokubaliwa bila kujali ukubwa wa muamala.",
    "who.eyebrow": "Nani anaweza kutumia Exxabay Go",
    "who.title": "Imeundwa kwa wauzaji waliothibitishwa",
    "who.card1_title": "Wauzaji waliothibitishwa sokoni pekee",
    "who.card1_desc": "Lazima uwe umekamilisha uthibitishaji kamili wa Exxabay TIN, leseni ya biashara, kitambulisho cha taifa, na picha za duka kabla ya kutumia Exxabay Go. Hakuna ubaguzi.",
    "who.card2_title": "Wauzaji wenye wateja wa WhatsApp na mitandao ya kijamii",
    "who.card2_desc": "Endelea kuuza mahali ulipo WhatsApp, Instagram, au Facebook ukiwa na safu ya malipo salama, iliyothibitishwa ambayo wateja wako wanaweza kuiamini.",
    "who.card3_title": "Wauzaji wanaokua zaidi ya sokoni",
    "who.card3_desc": "Pokea malipo kutoka kwa mteja yeyote unayemkuta popote, huku ukiendelea kutumia uthibitishaji wako wa Exxabay na wasifu wako wa uaminifu.",
    "protect.eyebrow": "Ulinzi wa mnunuzi",
    "protect.title": "Kila malipo yanalindwa",
    "protect.subtitle": "Mnunuzi anapolipa kupitia kiungo chako cha Exxabay Go, anaona jina lako lililothibitishwa na uhakikisho wazi wa uwajibikaji kabla ya kulipa.",
    "protect.item1": "Mnunuzi anaona jina lako la biashara lililothibitishwa na hadhi ya Exxabay Verified kabla ya kulipa",
    "protect.item2": "Kiungo cha malipo kinaonyesha kiasi halisi hakuna gharama zilizofichwa, uwazi kamili",
    "protect.item3": "Iwapo muuzaji atashindwa kuwasilisha bidhaa, Exxabay hutoa jina lake kamili, kitambulisho cha taifa, na anwani ya duka kwa hatua za kipolisi",
    "protect.item4": "Mnunuzi anaalikwa kufungua akaunti ya Exxabay baada ya malipo tu hulazimishwi kabla",
    "faq.eyebrow": "Maswali ya kawaida",
    "faq.title": "Maswali yanayoulizwa mara kwa mara",
    "faq.q1": "Je, ninahitaji kutangaza bidhaa ili kutumia Exxabay Go?",
    "faq.a1": "Hapana. Exxabay Go inahitaji tu namba ya simu ya mteja na kiasi. Hakuna tangazo la bidhaa, hakuna picha, hakuna uchaguzi wa kategoria. Imeundwa mahususi kwa mauzo nje ya jukwaa na mitandao ya kijamii.",
    "faq.q2": "Je, mteja wangu anaweza kulipa kutoka namba tofauti ya simu?",
    "faq.a2": "Ndiyo. Unaweka namba ya WhatsApp ya mteja wako ili kutuma kiungo. Lakini mteja anapofungua kiungo anaweza kulipa kutoka namba yoyote ya pesa za simu anayochagua. Hawafungwi na namba uliyoweka.",
    "faq.q3": "Nani analipa ada ya Exxabay Go?",
    "faq.a3": "Mteja analipa ada juu ya kiasi kilichokubaliwa. Wewe hupokea kila mara kiasi ulichoweka wakati wa kutengeneza kiungo. Ada inaonyeshwa kwa uwazi kwa mteja kabla ya kuthibitisha malipo.",
    "faq.q4": "Je, ada inaweza kubadilika baada ya kutengeneza kiungo?",
    "faq.a4": "Hapana. Ada inafungwa kabisa mara unapobofya kutengeneza. Hata kama Exxabay itabadilisha muundo wa ada baadaye, kiungo hicho maalum kitaendelea kuonyesha ada iliyohesabiwa wakati wa kutengenezwa.",
    "faq.q5": "Ninawezaje kupata ufikiaji wa Exxabay Go?",
    "faq.a5": "Exxabay Go inapatikana ndani ya dashibodi yako ya muuzaji mara uthibitishaji wako wa Exxabay unapokamilika. Kama bado hujathibitishwa, omba kuwa muuzaji kwenye Exxabay kwanza. Mchakato wa uthibitishaji huchukua hadi saa 48.",
    "faq.q6": "Kuna tofauti gani kati ya Exxabay Go na soko kuu?",
    "faq.a6": "Soko la Exxabay ni mahali wanunuzi wanapogundua bidhaa zako kwa kutafuta na kuvinjari. Exxabay Go ni kwa wateja unaowapata mwenyewe WhatsApp, Instagram, au popote unapouza. Sokoni, wauzaji hulipa kamisheni ya 10%. Kwenye Exxabay Go, wateja hulipa Tsh 1,500 + 1% na wauzaji hupokea 100% ya kiasi kilichokubaliwa.",
    "bottom.title": "Uko tayari kutumia Exxabay Go?",
    "bottom.subtitle": "Fikia Exxabay Go kutoka dashibodi yako ya muuzaji. Tengeneza kiungo chako cha kwanza cha malipo salama kwa chini ya dakika moja.",
    "bottom.apply_cta": "Bado hujathibitishwa? omba kuwa muuzaji",
  }
};


function getClickPesaFee(amount) {
  if (amount >= 500 && amount <= 999) return 54;
  if (amount >= 1000 && amount <= 1999) return 92;
  if (amount >= 2000 && amount <= 2999) return 124;
  if (amount >= 3000 && amount <= 3999) return 230;
  if (amount >= 4000 && amount <= 4999) return 380;
  if (amount >= 5000 && amount <= 9999) return 580;
  if (amount >= 10000 && amount <= 19999) return 920;
  if (amount >= 20000 && amount <= 39999) return 1150;
  if (amount >= 40000 && amount <= 49999) return 1572;
  if (amount >= 50000 && amount <= 99999) return 2136;
  if (amount >= 100000 && amount <= 199999) return 3240;
  if (amount >= 200000 && amount <= 299999) return 3660;
  if (amount >= 300000 && amount <= 399999) return 4080;
  if (amount >= 400000 && amount <= 499999) return 4340;
  if (amount >= 500000 && amount <= 599999) return 4820;
  if (amount >= 600000 && amount <= 799999) return 5230;
  if (amount >= 800000 && amount <= 999999) return 6146;
  if (amount >= 1000000 && amount <= 1999999) return 7210;
  if (amount >= 2000000 && amount <= 3000000) return 7960;

  return 0;
}

const modal = document.querySelector("#seller-modal");
const modalDialog = modal ? modal.querySelector(".modal__dialog") : null;
const closeTriggers = modal ? modal.querySelectorAll("[data-modal-close]") : [];
const languageToggle = document.querySelector("#language-toggle");
const productGrid = document.querySelector("#product-grid");
const cartPage = document.querySelector("[data-cart-page]");
let currentLanguage = localStorage.getItem("language") || "en";
let activeCard = null;
let lastFocusedElement = null;


const statusMeta = {
  verified: { icon: "OK", className: "status-badge--verified", labelKey: "verified" },
  pending: { icon: "!", className: "status-badge--pending", labelKey: "pending" },
  unverified: { icon: "X", className: "status-badge--unverified", labelKey: "unverified" }
};

function t(key) {
  return translations[currentLanguage][key] || translations.en[key] || key;
}

function formatNumber(value) {
  const number = Number(value || 0);
  return new Intl.NumberFormat(currentLanguage === "sw" ? "sw-TZ" : "en-US").format(number);
}

function translateDocumentStatus(status) {
  const normalized = String(status || "").toLowerCase();
  if (normalized === "submitted") return t("submitted");
  if (normalized === "missing") return t("missing");
  return status || t("missing");
}

function getTrustCopy(statusKey, fallback) {
  const key = `trustCopy${statusKey.charAt(0).toUpperCase()}${statusKey.slice(1)}`;
  return t(key) || fallback;
}

function applyStaticTranslations() {
  document.documentElement.lang = currentLanguage === "sw" ? "sw" : "en";
  document.documentElement.dataset.language = currentLanguage;

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    element.textContent = t(element.dataset.i18n);
  });

  document.querySelectorAll("[data-i18n-attr]").forEach((element) => {
    element.dataset.i18nAttr.split(",").forEach((pair) => {
      const [attribute, key] = pair.split(":").map((part) => part.trim());
      element.setAttribute(attribute, t(key));
    });
  });

  if (!languageToggle) return;

  languageToggle.setAttribute("aria-label", t("switchLanguage"));
  languageToggle.setAttribute("aria-pressed", String(currentLanguage === "sw"));
  languageToggle.querySelector(".language-toggle__option--sw").classList.toggle("is-active", currentLanguage === "sw");
  languageToggle.querySelector(".language-toggle__option--en").classList.toggle("is-active", currentLanguage === "en");
}

function applyCardTranslations() {
  document.querySelectorAll("[data-card-i18n]").forEach((element) => {
    element.textContent = t(element.dataset.cardI18n);
  });

  document.querySelectorAll("[data-stock-key]").forEach((element) => {
    element.textContent = t(element.dataset.stockKey);
  });

  document.querySelectorAll("[data-status-key]").forEach((element) => {
    const status = statusMeta[element.dataset.statusKey];
    element.textContent = `${status.icon} ${t(status.labelKey)}`;
  });
}

function getDocumentsFromCard(card) {
  return [
    {
      label: t("businessLicense"),
      file: card.dataset.licenseDocument,
      status: translateDocumentStatus(card.dataset.licenseStatus),
      url: card.dataset.licenseUrl
    },
    {
      label: t("taxClearance"),
      file: card.dataset.taxDocument,
      status: translateDocumentStatus(card.dataset.taxStatus),
      url: card.dataset.taxUrl
    },
    {
      label: t("idVerification"),
      file: card.dataset.idDocument,
      status: translateDocumentStatus(card.dataset.idStatus),
      url: ""
    },
    {
      label: t("storeRegistration"),
      file: card.dataset.storeDocument,
      status: translateDocumentStatus(card.dataset.storeStatus),
      url: ""
    }
  ];
}

function renderSellerModal(card) {
  if (!modal) return;

  const statusKey = card.dataset.trustStatus || "unverified";
  const status = statusMeta[statusKey];

  document.querySelector("#seller-modal-title").textContent = card.dataset.sellerName;
  document.querySelector("#seller-business").textContent = card.dataset.businessName;

  const statusBadge = document.querySelector("#modal-status-badge");
  statusBadge.className = `status-badge ${status.className}`;
  statusBadge.textContent = `${status.icon} ${t(status.labelKey)}`;
  const trustCopy = getTrustCopy(statusKey, card.dataset.trustCopy);
  document.querySelector("#modal-status-copy").textContent = trustCopy;

  document.querySelector("#documents-list").innerHTML = getDocumentsFromCard(card).map((documentItem) => {
    const action = documentItem.url
      ? `<button class="btn btn--outline" type="button" disabled href="${documentItem.url}" target="_blank" rel="noopener">${t("Available on request")}</button>`
      : `<button class="btn btn--outline" type="button" disabled>${t("unavailable")}</button>`;

    return `
      <div class="document-item">
        <div>
          <div class="document-item__name">${documentItem.label}</div>
          <div class="document-item__status">${documentItem.file} - ${documentItem.status}</div>
        </div>
        ${action}
      </div>
    `;
  }).join("");

  document.querySelector("#metric-products").textContent = formatNumber(card.dataset.totalProducts);
  document.querySelector("#metric-orders").textContent = formatNumber(card.dataset.completedOrders);
  document.querySelector("#metric-rating").textContent = `${card.dataset.rating || "4.8"} ${t("stars")}`;
  document.querySelector("#trust-message-copy").textContent = trustCopy;
}

function openSellerModal(card) {
  if (!modal || !modalDialog) return;

  activeCard = card;
  lastFocusedElement = document.activeElement;
  renderSellerModal(card);

  modal.classList.add("is-open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-lock");
  modalDialog.focus();
}

function closeSellerModal() {
  if (!modal) return;

  modal.classList.remove("is-open");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-lock");
  activeCard = null;

  if (lastFocusedElement) {
    lastFocusedElement.focus();
  }
}

function setLanguage(language) {
  currentLanguage = language;
  // Save the selected language
  localStorage.setItem("language", language);

  applyStaticTranslations();
  applyCardTranslations();

  if (modal && modal.classList.contains("is-open") && activeCard) {
    renderSellerModal(activeCard);
  }
}

if (productGrid) {
  productGrid.addEventListener("click", (event) => {
    const trigger = event.target.closest("[data-seller-trigger]");
    if (!trigger) return;

    const card = trigger.closest(".product-card");
    if (card) {
      openSellerModal(card);
    }
  });

  productGrid.querySelectorAll(".product-card").forEach((card) => {
    card.addEventListener("pointerenter", () => card.classList.add("is-hovered"));
    card.addEventListener("pointerleave", () => card.classList.remove("is-hovered"));
  });
}

closeTriggers.forEach((trigger) => {
  trigger.addEventListener("click", closeSellerModal);
});

if (languageToggle) {
  languageToggle.addEventListener("click", () => {
    setLanguage(currentLanguage === "en" ? "sw" : "en");
  });
}

function parseMoney(value) {
  return Number.parseFloat(String(value || "0").replace(/,/g, "")) || 0;
}

function formatMoney(value) {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function getCsrfToken() {
  return document.querySelector("[name=csrfmiddlewaretoken]")?.value || "";
}

async function syncCart(item) {
  const action = item.dataset.pendingAction;
  const url = item.dataset.pendingUrl;

  if (!url) return;

  const quantityInput = item.querySelector("[data-cart-quantity]");

  const payload = {
    action,
    quantity: Number.parseInt(quantityInput?.value, 10) || 1,
  };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCsrfToken(),
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error("Cart update failed");
    }

    return await response.json();

  } catch (error) {
    console.error(error);
  }
}

function updateCartTotals() {
  if (!cartPage) return;

  let itemCount = 0;
  let cartTotal = 0;

  cartPage.querySelectorAll("[data-cart-item]").forEach((item) => {
    const price = parseMoney(item.dataset.price);

    const quantityInput = item.querySelector("[data-cart-quantity]");

    const quantity = Math.max(
      1,
      Number.parseInt(quantityInput.value, 10) || 1
    );

    const subtotal = price * quantity;

    item.dataset.quantity = String(quantity);

    quantityInput.value = String(quantity);

    item.querySelector("[data-cart-subtotal]").textContent =
      formatMoney(subtotal);

    itemCount += quantity;
    cartTotal += subtotal;
  });


  const fee = getClickPesaFee(cartTotal);
  const amountPayable = cartTotal + fee;

  cartPage
    .querySelectorAll("[data-cart-total], [data-cart-grand-total]")
    .forEach((element) => {
      element.textContent = formatMoney(cartTotal);
    });

    const feeEl = cartPage.querySelector("[data-payment-fee]");
  if (feeEl) {
    feeEl.textContent = formatMoney(fee);
  }

  const payableEl = cartPage.querySelector("[data-amount-payable]");
  if (payableEl) {
    payableEl.textContent = formatMoney(amountPayable);
  }


  const countElement = cartPage.querySelector("[data-cart-count]");

  if (countElement) {
    countElement.textContent =
      `${itemCount} item${itemCount === 1 ? "" : "s"}`;
  }
}

function queueCartAjax(item, action) {
  const url =
    action === "remove"
      ? item.dataset.removeUrl
      : item.dataset.updateUrl;

  item.dataset.pendingAction = action;
  item.dataset.pendingUrl = url || "";
}

function initializeCartPage() {
  if (!cartPage) return;

  cartPage.addEventListener("click", async (event) => {
    const item = event.target.closest("[data-cart-item]");

    if (!item) return;

    const input = item.querySelector("[data-cart-quantity]");

    const max =
      Number.parseInt(input.getAttribute("max"), 10) || Infinity;

    const currentValue =
      Number.parseInt(input.value, 10) || 1;

    // Increase quantity
    if (event.target.closest("[data-cart-increase]")) {

      input.value = String(
        Math.min(max, currentValue + 1)
      );

      queueCartAjax(item, "update");

      await syncCart(item);

      updateCartTotals();
    }

    // Decrease quantity
    if (event.target.closest("[data-cart-decrease]")) {

      input.value = String(
        Math.max(1, currentValue - 1)
      );

      queueCartAjax(item, "update");

      await syncCart(item);

      updateCartTotals();
    }

    // Remove item
    if (event.target.closest("[data-cart-remove]")) {

      queueCartAjax(item, "remove");

      await syncCart(item);

      item.classList.add("is-removing");

      window.setTimeout(() => {
        item.remove();
        updateCartTotals();
      }, 160);
    }
  });

  cartPage.addEventListener("change", async (event) => {

    if (!event.target.matches("[data-cart-quantity]")) return;

    const input = event.target;

    const item = input.closest("[data-cart-item]");

    const max =
      Number.parseInt(input.getAttribute("max"), 10) || Infinity;

    const value =
      Number.parseInt(input.value, 10) || 1;

    input.value = String(
      Math.min(max, Math.max(1, value))
    );

    queueCartAjax(item, "update");

    await syncCart(item);

    updateCartTotals();
  });

  updateCartTotals();
}

function initializeAuthRoleForms() {
  document.querySelectorAll("[data-auth-role-form]").forEach((form) => {
    const roleInputs = form.querySelectorAll('input[name="role"]');
    const sellerFields = form.querySelector("[data-seller-fields]");

    function syncRoleState() {
      const selectedRole = form.querySelector('input[name="role"]:checked')?.value || "buyer";

      roleInputs.forEach((input) => {
        const card = input.closest(".auth-role__card");
        if (card) {
          card.classList.toggle("is-selected", input.checked);
        }
      });

      if (sellerFields) {
        sellerFields.classList.toggle("is-hidden", selectedRole !== "seller");
      }
    }

    roleInputs.forEach((input) => {
      input.addEventListener("change", syncRoleState);
    });

    syncRoleState();
  });
}


function initializeFooterNewsletter() {
  document.querySelectorAll("[data-footer-newsletter]").forEach((form) => {
    const input = form.querySelector('input[type="email"]');
    const status = form.querySelector("[data-footer-newsletter-status]");
    const button = form.querySelector('button[type="submit"]');
    const spinner = button.querySelector(".spinner");
    const buttonText = button.querySelector(".btn-text");

    form.addEventListener("submit", async (event) => {
      event.preventDefault();

      if (!input.checkValidity()) {
        input.reportValidity();
        return;
      }

      const formData = new FormData(form);

      const csrfToken = document.cookie
        .split("; ")
        .find(row => row.startsWith("csrftoken="))
        ?.split("=")[1];

      // show spinner 
      button.disabled = true;
      spinner.style.display = "inline-flex";
      buttonText.textContent = "Subscribing...";
      status.textContent = "";

      try {
        const response = await fetch("/users/subscribe/", {
          method: "POST",
          body: formData,
          headers: {
            "X-CSRFToken": csrfToken,
          },
        });

        const data = await response.json();

        if (data.error) {
          status.textContent = data.error;
        } else if (data.message) {
          status.textContent = data.message;
          form.reset();
        }

      } catch (error) {
        status.textContent = "Sorry, we could not subscribe you right now.";
      } finally {
        button.disabled = false;
        spinner.style.display = "none";
        buttonText.textContent = "Subscribe";
      }
    });
  });
}

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && modal && modal.classList.contains("is-open")) {
    closeSellerModal();
  }
});

setLanguage(localStorage.getItem("language") || "en");
initializeCartPage();
initializeAuthRoleForms();
initializeFooterNewsletter();